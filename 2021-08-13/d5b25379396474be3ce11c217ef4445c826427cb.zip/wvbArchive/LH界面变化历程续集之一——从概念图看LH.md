﻿那么，废话不多说，Let us start![太开心]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/f0a59f188618367a1a18d09c23738bd4b11ce5d0.jpg)
***
首先，我们从MSX“LH Day”开始。
“LH Day“就是宣传PDC 2003的一些视频，有一些视频在由观上，有兴趣的可以通过BA Wiki的Lh Day条目提供的连接上看。虽然视频上的系统风格是Plex初期，但PDC展示的却是暗黑Aero风的4051。下面我们来分析一下。
插句，这些图片由一个微软员工建立的网站提供的。另外还有些Demo程序，下载地址还是在BA Wiki上。
哇！一眼望去，开始菜单，任务栏，和侧边栏都是透明的。这可能是DCE效果吧。
But，他们的透明效果还是不同。
开始菜单透明度较低，所以程序菜单和任务栏稍微透明些，侧边栏是很漂亮的毛玻璃效果。
任务栏是新风格的（在后面的图片你会明白的），但开始菜单按钮的高亮却是微标变XP彩色风[喷]
侧边栏的图标都是蓝白盲化，且边缘有反光效果。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/553a51d2d539b60032189af6e450352ac45cb796.jpg)
***
资源管理器，除了收藏网址放在上面，链接地址栏与菜单栏在一起，工具栏可隐藏。（这些都没实现）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/dba428c3d5628535d62a46609def76c6a5ef639a.jpg)
***
看到前进后退按钮了吗？其实他的前身长这样。
没错，LH的就只是加强了周围的光弧效果和增加底部发光效果罢了。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/191a5a6c55fbb2fb6f373a50424a20a44723dc4d.jpg)
***
有人说那两个前进后退按钮存在于只是概念图而已，没有实际应用。
听到这句话我笑了。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/89e3183f6709c93d0cc4b4b5923df8dcd00054b7.jpg)
***
还是7楼的图，再仔细看，发现连窗口边框都没有，扩大手柄直接显示在滚动条下面，真超前。
地址栏一下的背景都是渐变，感觉浑然一体。
左栏还是Plex早期风格，但是Enjoy Music栏的上拉按钮却和其他都不一样。
每个文件都没有文件名，不用急，上面不是有文件筛选吗？（不愧是WinFX给的底子）
另外图标有淡阴影，且高亮也是动画。
预览栏支持媒体播放（用的是RMA），且进度条也很好看。
再说说RMA版的WMP，两边有反光，底部有发光效果，其他与Plex早期风相同。控制按钮水晶化且与背景融合好评！
这些功能大部分都出现。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/f32afb83d158ccbfcf6cd37914d8bc3eb3354192.jpg)
***
考試考砸了，求安慰。[不高兴]
搜索界面，边缘有反光效果，就连搜索框也有玻璃反光效果！ 背景真的很赞！[真棒]
水晶图标扁化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/ebecf02ad40735fa7532e7ff93510fb30d2408af.jpg)
***
还有个叫 sounds like的功能，除了鼠标悬停在某个音乐上会显示详细信息（可惜只应用在图片预览上）其他的都没实现。[不高兴]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/c722407e9e2f07081e453047e424b899a801f22e.jpg)
***
对了，这里有一些Demo Program。htt[真棒]p://heesu[真棒]ng.jctsolut[真棒]ion.com/hs_portfol[真棒]ioweb_MS/我想叫吧友们测试一下。
1. bin8.exe - Longhorn Listmaker
2. burn1.exe - 刻录到CD向导
3. e2e photos.exe - 我的图片和视频（这个的基本功能是在Windows 10的照片应用程序中，虽然不是眼睛糖果和自动旋转功能）
4. msxday.exe - 我的音乐库
5. tree1.exe - Longhorn Listmaker导航
***
后来，4039出现了。虽然还是Plex风格，但与概念图产生了巨大的差异。于是，某位微软员工又制作了新的概念图。
小工具透明效果与任务栏一样了。窗口边框又出现了，只不过是银色，这很像4039开启Aero但没有开启DCE效果的样子。滚动条也变银。另外，”三大金刚“没了图标。前进按钮与4039不同的地方就是箭头，可能是制图人讨厌4039的XP箭头吧。
介绍栏左栏也变成4039样式。
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/913cc087c9177f3ed8bc834a7dcf3bc79d3d56e6.jpg)
***
这幅图是镇楼图，对吧。
可是里面的玄机你了解多少？对了，就是那个篮子!
那为什么要那个篮子呢？因为篮子是一个能处理多个文件的小程序。
以前，我们处理文件（复制，粘贴或刻录等等）都是用资源管理器吧。（现在也是如此）处理单个文件夹里的文件就很简单，可是开N个窗口处理多个文件夹就变得麻烦多了，而且效率低下（要不停切换窗口，切换到不同的文件夹）。
篮子就很好地解决这个问题：小窗口能省下许多空间；因为添加到篮子必须得拖动，所以没有存在遗忘那个文件需要处理的麻烦，且放在一起也好管理；更重要的是，可以新建很多的篮子，不同的篮子用来处理不同的文件。可惜这个在重组前却没有了。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/38049037afc379315b4f4662e6c4b74542a9114f.jpg)
***
小工具的RMA还是Plex早期风格，但多了个最大化按钮，高亮严重好评！滚动栏也透明且滚动条变蓝好评！篮子在侧边栏上显示的是几个篮子的List，也许是篮子管理器吧。另外标题栏上的”小红点“（因为它is not 红色的），感觉那时的微软很超前。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/4cc7e045ebf81a4cf3c62e82da2a6059272da6ff.jpg)
***
在对比一下，此时的篮子（4039与4033一样）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/11c9419659ee3d6ddda44b804e166d224e4ade15.jpg)
***
接楼上说的，虽然背景不是同一的渐变色。但缩略图的显示方式和下面显示文件的数量和大小真让我惊讶。
再来看看，MSX设计的WMC。
封面和进度条大赞，背景也很不错！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/ed9abac551da81cb30abab805f66d01608243126.jpg)
***
然后，4050也出现了，Aero的界面震撼了MSX，于是MSX在PDC2003开始前的那几天又发布了新的概念图。[汗]
这些图的内容是有关光盘烧制，侧边栏与原来任务栏的开始菜单按钮（翡翠圆球好评！）和托盘（暗夜时钟也好评！）合为一体，小工具就不得不居中，任务栏也就只是单纯地显示任务条，而且反射效果也没有。标题栏的三大金刚还是4039的风格，但边框右下角不是圆球形状的扩大手柄。返回按钮多出来个”Back“莫名喜感，aurora当然不会缺席，有趣的是，磁盘图标突到外面去，仔细看，还有阴影呢！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/973e1cca0a46f21fd112491efb246b600d33ae4a.jpg)
***
于是，虽然PDC2003结束了。但MSX没有结束制作LH的概念图，所以我们还能看到一些Jade风格的图片。
补充一下，还有这张图。虽然是Plex风格的，但进度条和滚动条却是Jade风格。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/a9d0df98a9014c08427522e8077b02087af4f422.jpg)
***
偷偷告诉你，这幅图的某一部分是LH 2008增强包安装程序的欢迎图。
图标变得猎奇起来了，但侧边栏除了邮件列表、天气和以及省略控制栏的RMA版的WMP这两个小组件以外，与LHR（或叫LH 2008也行）一样。开始菜单是透明的，且覆盖住了任务栏的一部分，且任务栏上的开始按钮不见了。还有程序区域在右边，关机、切换用户、帮助和设置都在所有程序下面，左栏上面有3D的用户头像，下面是一个透明的微标。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/75dea15d1038534397dbf16c9e13b07ecb808858.jpg)
***
这是资源管理器，收藏夹的网址又跑出去了，且预览图是彩色。
暗黑Aero圆环效果没了
3D视图（我知道叫那个P什么的，但我记性真”好“），的背景是4050的某个Build，左栏移到了上面，而左栏月份排序放到了下面，网格表示图片数量真的很赞！滚动条和标签条的聚光玻璃板聚光方向不一样。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/fcc53b6134a85edffd29b19044540923df5475d5.jpg)
***
游戏资源管理器，aurora又变成竖极光。
邀请他人玩游戏隐藏在其中。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/22249002918fa0ecf7be2cbe2b9759ee3c6ddb7a.jpg)
***
明日预告：这张图也具有一些意义，因为这幅图宣传了多年后即将出现的Windows Live服务！（考试又开始开始复习了，可能不更）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/035de527cffc1e175a04c7824790f603718de9c4.jpg)
***
一天后终于开始更了。@人先。
开始菜单只要光标悬浮在左栏某项，有淡绿高亮且头像变成立体动画。
侧边栏多几个组件，与Live有关。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/7a738e51352ac65c54023ac5f6f2b21192138a72.jpg)
***
live服务的概念，差不多与某Q的空间是一样的。但界面却比某Q好多了（但不知道实际上是什么样）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/0b0f9cecab64034fa0819db0a2c379310b551d29.jpg)
***
空间的一些概念也很超前，比如选项卡上显示的是两个空间。一个是公开空间，另一个是私人空间。
且私人空间的板块分为：聊天、博客、购买的专辑和文档，当然板块可以增添，主题也可以改变。
导入图片向导和现在相似，只不过没有箭头而已。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/8c4b0b80800a19d835dac1b33efa828ba41e46a4.jpg)
***
另外，登陆界面。不是和以往一样是进入安全界面，而是直接弹出切换账户窗口。
从输入内容看出，用户名是邮箱（hotmail是微软的）这说明微软要通过.Net来把Windows变成互联网系统。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/f6f45df23a87e9500385b3da1d385343f9f2b4ef.jpg)
***
再补充楼上登录窗口下面有倒影好评，切换用户的动画，也挺好看的。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/8861b642ad4bd113b72ef48457afa40f49fb059e.jpg)
***
In end,我们以一张图来结束我们的帖子。
（别走开，还有更多彩蛋）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/d7dfb30635fae6cdcc67e7d702b30f2440a70fae.jpg)
***
Lh days videos: youtube b9if QvQ CO7Y
WVvtzkpyRTg
HFTqOzKaSl8
***
亚马逊Demo：yourube kbYRWfhIg1k
由Carter Maslan的Longhorn技术实现的商业解决方案(2004年)
商业地产（视频） 3jt3u-dC7s0
金融服务（视频） 19Ii0oQbGt8
医疗保健（视频） G1pJf5FR8J0
制造业（视频） 7tlkeD5A3Fg
***
原来，LH Day早有人搬运过了。
最后一个大彩蛋，所有的Lh概念演示的视频都在这里。htt[真棒]ps://tho[真棒]unsell.co.uk/files/lh-videos/
还是补一个最初的概念图吧，没什么好说的，只是有个浓浓的nt5.1风格的侧边栏。[汗]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5953726101/dba428c3d5628535a4ae74f39def76c6a5ef638f.jpg)
***
最后的概念图，标题栏上的三大金刚的样式很特别，什么的光弧与顶部的距离更大了，任务栏的反光效果没了。
资源管理器的介绍栏的极光变成了斜纹，介绍栏右上角还有反光斑，与标题栏的反光斑连成一条线，十分契合。
不仅是左栏的文字随介绍栏上的图标变化，而且分类栏的文字也是。
***
侧边栏在任务栏的下面，而且小部件变成了圆角，还有左上聚光渐变的效果。
感觉整个概念图都有圆角的元素，大到屏幕的四角，小到边栏秀的图片，都是如此。