这是我之前的预告帖：预告•即将发布Vista更新合集最终版https://tieba.baidu.com/p/5068625497
什么是Windows Vista最终更新合集呢？即收集Windows Vista SP2后至2017年4月11日结束支持期间，微软向Windows Vista发布的所有更新，目前已经收集完毕并正式发布，包括32位和64位的，64位的叫打包叫Vista-Update-Final-x64.zip，32位的打包叫Vista-Update-Final-x86.zip，里面具体有什么呢？如下图所示：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/0f36b2638535e5dd6ba7dd107fc6a7efcc1b626f.jpg)
就不用我解释了吧，一看名字就懂了[吐舌]
每个文件夹里面的具体内容：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/9596e234e5dde7111d593b39aeefce1b9f16616f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/c5c182dce71190eff870ea10c71b9d16fffa606f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/a529801090ef76c6285983e49416fdfaad51676f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/a7e5f7ee76c6a7ef5eadd0e9f4faaf51f1de666f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/d01b11c7a7efce1b0ca0b005a651f3deb68f656f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/3632c0eece1b9d166f4ce2aefadeb48f8e54646f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/e71ba91a9d16fdfa3ce7be21bd8f8c5496ee7b6f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/8eeffa17fdfaaf516768f970855494eef21f7a6f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/dde29afbaf51f3de2139c1ab9deef01f3829796f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/bd0ec850f3deb48f1ae2d911f91f3a292ff5786f.jpg)
所有更新通过Windows Update检查到的，并且在Microsoft Update Catalog下载的或者在微软官网下载的，大家尽可放心[吐舌]
谨以此合集纪念Windows Vista。
Vista走了，十年前，你如极光般华丽，一代天骄。那一年，你横空出世，让我对你倾心不已；而现在，你走了，一路走好[泪]
二楼放出下载链接
Vista最终更新合集第二版Vista-Update-Final-V2发布了：64位的为Vista-Update-Final-x64-V2.zip,32位的为Vista-Update-Final-x86-V2.zip
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/0253be32c895d143ac8deb1379f082025baf077f.jpg)
更新日志：
1.根据吧友@wq8245 的建议，调整了一下更新分类，增加了1.DX11+KB2117917+KB2761494这个分类，把IE9的两个先决条件更新KB971512、KB2117917移入这个分类，并且把5.Optional Update中的KB971513、KB971514、KB960362、KB2761494移入这个分类，其中KB971512、KB971513、KB971514、KB960362是DX11更新，而KB2761494是Windows驱动程序框架版本1.11累积更新；把IE9的累积更新由4.Important Update移入2.IE9分类
***
2.修复了吧友@wq8245 发现的已知问题，即 Windows DreamScene 内容包收藏夹 里面的KB941236是空文件，估计下载过程出错了，当时没注意到，感谢吧友@wq8245的反馈，现在KB941236已经重新下载了，并替换了空文件，现在已经没问题了
***
3.新增了Microsoft Camera CodecPack，这是微软开发的一个相机编解码器包，使 Windows 照片库能够查看各种特定于设备的格式，包括 RAW 文件。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/2b946b328744ebf87bac6b0fd3f9d72a6159a712.jpg)
Microsoft Camera 编解码器提供对以下设备格式的支持：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/79f5463eb80e7becc1070cd1252eb9389a506b12.jpg)
4.新增了Microsoft Security Essentials，里面放了MSE的安装包和病毒库更新包
***
5.新增了Silverlight
***
6.新增了Microsoft Bing Input，即微软必应拼音输入法，其实很喜欢这个输入法，可惜在2015年7月推出最后一版后就停更了，本次收录的是它的最后一版。
6月更新日到了，微软这次很给力，给不受支持的旧系统也提供了更新，根据微软官方博客的说法，此次给不受支持的旧系统提供更新是为了保护用户免受潜在的国家级别网络攻击活动的威胁（protect against potential nation-state activity）,此次微软给不受支持的Windows XP, Windows Vista, Windows 8, Windows Server 2003和Windows Server 2003 R2都提供了更新，原文截图：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/a00afe24bc315c6051e9d8af87b1cb1348547763.jpg)
***
原文链接：https://blogs.technet.microsoft.com/msrc/2017/06/13/june-2017-security-update-release/
原文大意：微软针对旧版本操作系统发布特别的安全更新，保护用户免受潜在的国家级别安全隐患活动的威胁
在本周微软例行的“周二安全更新日”，我们已采取了相应措施提供特别的重要安全更新，解决风险较高的漏洞问题，防止黑客利用这些漏洞制造国家级别网络攻击的活动或泄漏信息。在本周发布的所有安全更新中，有些是全新开发的，有些则是面向旧版本操作系统的（根据后续特别支持协议相关规定），用户从即日起就可以进行下载和安装。开启了自动更新功能的用户无需进行任何操作便可受到保护。对于需手动操作更新或旧版操作系统的用户，我们鼓励他们尽快应用这些更新。
我们的安全团队严密监控不断涌现的各种威胁，据此来排定优先级别，安排相关工作，并及时采取相应措施。我们致力于确保用户免受这些潜在威胁的攻击，同时我们也善意提醒仍使用旧版本操作系统（如Windows XP等）的用户尽早前往“微软下载中心”（Download Center）或”更新目录“（Update Catalog）优先下载和安装这些重要的安全更新。
我们对不再延长支持阶段的微软操作系统发布特别安全更新，与我们的标准服务政策并不相悖。基于我们的安全工程师对当前威胁环境的评估，我们决定为更多的 Windows 用户提供安全更新。我们依然建议用户升级至最新版本的操作系统。最新版本的现代操作系统采用了新的深度防护措施，能够为用户提供更好的保护。如果使用的依然是陈旧版本的操作系统，即使进行了全面的更新，它仍然会缺乏最新的安全特性和技术。
运行仍然处于正常服务支持的操作系统（如 Windows 10 和 Windows 8.1 等）并启动了自动更新功能的用户无需进行任何操作，便可受到保护，系统会自动下载和安装这些安全更新。（Via：微软中国）
Eric Doerr
微软安全响应中心总经理 Eric Doerr
***
更多信息：
***
详细更新列表请点击微软安全公告 4025685 进行查阅
使用 Windows Server 2008、Windows 7、Windows Server 2008 R2、Windows Server 2012、Windows 8.1、Windows 8.1 RT、Windows Server 2012 R2、 Windows 10、以及 Windows Server 2016 的用户请点击 Microsoft Knowledge Base Article 4025686 获取帮助
使用 Windows XP、Windows Vista、Windows 8、Windows Server 2003、以及 Windows Server 2003 R2 的用户请点击 Microsoft Knowledge Base article 4025687 获取帮助
使用 Windows Embedded 版本的用户请点击 Microsoft Knowledge Base article 4025688 获取帮助
若不清楚您使用的是哪个版本 Windows 产品，请点击此处查询
更多疑问请点击常见问题
***
下面我们说说Vista，微软给不受造成的旧系统保护用户免受潜在的国家级别网络攻击活动的威胁（protect against potential nation-state activity）写了一份《Microsoft 安全公告 4025685： 旧平台指南： 2017，6 月 13》链接https://support.microsoft.com/zh-cn/help/4025687/microsoft-security-advisory-4025685-guidance-for-older-platforms，上面列了三个表格
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/92ef69f51bd5ad6e7d84d7aa8bcb39dbb7fd3c62.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/f3ed8cc5b74543a94a66498c14178a82b8011462.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/17d876dea9ec8a139767e4a0fd03918fa1ecc063.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5070482430/0a649102738da977e843356bba51f8198718e37c.jpg)
***
其中表格1中列举的MS08-067、MS09-050、MS10-061、MS14-068、MS17-010是今年4月之前的安全公告，对Vista影响的漏洞已经修复了，MS17-013漏洞不影响Vista。而表2、3上的安全公告有5个影响Vista，微软把修复这5个安全公告的漏洞的更新于6月更新日提供给Vista，此次6月更新日Vista收到的更新为KB4018271、KB4018466、KB4019204、KB4021903、KB4024402这五枚更新，下面我将和大家分享这五枚更新：