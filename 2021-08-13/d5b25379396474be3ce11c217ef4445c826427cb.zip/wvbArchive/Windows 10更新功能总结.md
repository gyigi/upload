渣图嗔楼
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/833aa4fcfc0392453a48e7958f94a4c27f1e25a4.jpg)
Win10预览版9834(2014.9.xx)
相比win8.1
1.开始屏幕被割舍，成为开始菜单
2.应用商店里的应用全部窗口化
3.小娜的雏形搜索按扭出现
4.虛拟桌面功能出现
5.任务栏透明度比8.1高很多
6.窗口边框消失
7.出现通知中心
Win10预览版9841(2014.10.1)
1.通知中心被隐蔽
2.修复大范围bug，以稳定和惊艳著称
Win10预览版9845(2014.10.xx)
1.通知中心再次出现
Win10预览版9888更新内容(2014.11.29)
1.内核版本提升为NT10.0
2.离线地图
3.无密码用户直接登录
4.把文件管理器和桌面右键菜单与开始菜单或开始屏幕右键菜单统一设计。
5.新的滑动式窗口动画
6.新的“设置”应用
Win10预览版9901更新内容(2014.12.14)
1.Cortana小娜/Xbox应用首次出现
2.采用新版UI界面
3.可备份应用数据到OneDrive
4.原生支持FLAC音频
5.存储感知
6.Modern全新设计改进
7.新的图标出现
8.计算器应用只剩下Modern版，而且这一版本和之前的UI也有很大区别。
9.双子模式出现
10.新的声音
7、Feedback反馈
全新的通用设置程序；资源管理器中的主页按钮支持自定义显示我的计算机或者常用内容
8、改善切换窗口功能
合并了以前的任务视图，保留了大量缩略图。这样可以帮助用户找到“熟悉”的感觉。
9、完善资源管理器
主页能快捷显示最近的内容
10、增加波斯日历
11、增加应用全屏按扭
Win10预览版10036新内容(2015.03)
1.新的WiFi设置
2.任务视图强化，“添加桌面”被放置到右侧，您可以轻松将窗口拖曳至其他桌面。
3.反馈信息数据追踪
4.开始菜单透明化
5.细节优化
6.原生支持文件保存为PDF格式
7.支持P2P更新，升级提速
Win10预览版10049新内容(2015.03.31)
1、全新斯巴达浏览器
2、bug修复
3、计算器、提醒和时钟“洗白”这两款应用的改进主要在UI上，之前的黑色变成了白色。计算器数字键加大、字号加粗，加入更多运算符号。“提醒和时钟”应用图标也进行了缩小处理，没有其他明显改变。
4、设置应用图标整体颜色加深，由之前的青绿色变成了深蓝色，“个性化”和“设备”功能图标改变。
5、神秘应用Bio Enrollment
6、全新音乐和视频预览应用亮相
7、“快速访问”改进
8、坐和放宽问题得到修复[怒]
Win10预览版10056新内容(2015.4.11)
1.更多个性化设置功能终于被放到了“设置”页面中，现在可以在这里设置桌面背景和系统颜色了
2.在平板模式设置中新增了“平板模式下隐藏任务栏应用图标”选项
3.新增无线设备控制权限设置
4.新增账户信息访问权限控制
5.斯巴达浏览器中支持PDF文档另存为
6.正式启用全新任务栏时间/日期弹出窗口
7.回收站等系统图标也有所变化，细节改进
8.斯巴达浏览器已成为系统默认的浏览器
Win10预览版10125(2015.5.25)
1.遥测和诊断隐私设置发生了变化
2.Win+C快捷键打开Cortana，而不再是Charm菜单
3.ExtendedExecution API的变更
4.Windows Hello登录岀现
5.相当多的图标都已被重新绘制
6.新版“网络”应用Network Beta已经岀现
7.改善开始菜单的个性化定制和平板模式下的返回按钮等
Win10预览版10134(2015.6.6)
1.提供了关闭预览版更新的开关
2.Edge浏览器“主页”按钮加入
3.截图工具出现延迟
4.全新系统更新界面
5.全新“人脉”应用。
Win10预览版10147(2015.6.20)
1.可降级Win7/Win8.1
2.Edge浏览器密码管理器现身
3.正式启用Edge浏览器图标，同时支持标签拖拽
4.Cortana改进，增加任务栏问候功能等
5.《时钟》和《日历》应用也得到了更新，支持黑色主题，Edge浏览器也已经支持黑色主题。
6.Phone Companion(手机伴侣)》应用已经出现
Win10预览版10158(2015.6.30)
1.改进Cortana
2.新版照片应用
3.细节优化
Win10预览版10159(2015.7.1)
1.启用全新的登录界面，支持将登录界面背景设置为桌面背景
2.英雄壁纸作为默认壁纸出现
3.修复了超过300项系统BUG，并且增强了系统稳定性。
Win10预览版10162(2015.7.3)
1.改善了稳定性，同时提高了续航时间，提升运行效率并且有了更好的软件兼容性。
Win10预览版10166(2015.7.10)
1.加入Microsoft WiFi应用
2.Groove品牌正式启用
3.Edge浏览器微调
4.重新默认激活
Win10预览版10176(2015.7.5)TH1分支
系统属性加入了Windows10标识
Win10 build 10240(2015.7.29)TH1分支正式版
Edge浏览器升级
Win10 build 10525(2015.8.19)TH2分支
1.彩色标题栏回归
2.采用了全新压缩数据存储
Win10 build 10532(2015.8.28)TH2分支
1.改进右键菜单，外观更加Modern。
2.Windows反馈中加入分享功能。可通过分享按钮反馈，也可复制链接进行分享。
3.Edge浏览器还带来了一些新特性，性能大幅提升。
4.Chakra核心增加了新的特性
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/b6f7148ca9773912cada51fbf0198618347ae2a6.jpg)
Win10 build 10537(2015.9.15)TH2分支
1.右键菜单的背景颜色更深了。
2.Edge浏览器WebRTC连接增加了隐藏本地IP地址的功能。
3.开始菜单导航更快捷
在开始菜单的“所有程序”中，点击字母分组的大写字母进行应用之间的快速导航跳转，速度比之前更快。
4.开始菜单、操作中心、任务栏和标题栏的颜色可根据用户喜好自定义
5.IE11不再支持EdgeHTML。
Win10 build 10576(2015.10.30)TH2分支
1.右键菜单增加“打分和评论”以及“共享”等内容
2.“电源”菜单增加了横向宽度
3.Edge浏览器的多媒体投影：能够使用Edge浏览器将视频、图片和音频文件投影到任何在当前网络已激活Miiracast和DLNA设备上。在Edge浏览器的PDF文件中咨询语音助手Cortana：当使用Edge浏览器阅读PDF文件并选中文本的时候，可以右键选择“Ask Cortana”获得额外信息。
4.升级Xbox Beta应用
5.出现Sway应用，此应用用于网页设计
Win10 build 11082 11099(2015.12)RS1分支
1.底层架构进行统一改进
Win10 build 14251 14257(2016.1)RS1分支
1.build与WP进行统一，继续底层统一核心完善，为接下来的新功能作准备
Win10 build 14267(2016.2.19)RS1分支
1.Cortana中加入激 活音乐搜索按钮，就在Cortana界面的右上角。
2.微软Edge浏览器中收藏夹栏改进：如果你在Edge中开启了收藏夹功能，现在可以在收藏夹栏右键点击，可以选择仅显示图标或者切换到名字和图标显示，另外右键点击也可以直接创建新的收藏夹。
3. 退出微软Edge浏览器清理浏览数据
4. 微软Edge浏览器加入下载提醒，选择文件保存位置
5. 《消息+Skype》应用改进：现在你可以在新的Skype消息中点击左下角的回形针图标，将照片作为附件发送。另外你还可以调用相机应用拍照，直接附件到Skype消息或者发送你的地理位置
6.临时文件可以不放在C盘
7.新增开始屏幕布局等云备份
Win10 build 14271(2016.2.25)RS1分支
1.优化了任务栏中的图标，使其在高分辨率的情况下更加清晰
2.在Action Center加入了右键按扭
3. 扩大了 Action Center “全部清除”的点击面积，方便用户使用
4.修复大量bug
Win10 build 14279(2016.3.5)RS1分支
1.Cortana正式支持西班牙语（墨西哥地区）、葡萄牙语（巴西地区）、法语（加拿大地区）。这些地区同样也支持使用本地化功能，例如寻找附近的餐馆等等。
2.登陆背景是你的锁屏壁纸。我们将在未来的版本中加入对微软锁屏壁纸支持。优化了两个界面之间的流畅性
3.微软小娜支持不设时间提醒你做事情
4.任务栏设置中心整合入系统设置APP
5.修复了大量bug
Win10 build 14295(2016.3.26)RS1分支
修复bug
Win10 build 14316(2016.4.7)RS1分支
***
1.Edge浏览器
1.1 拖拽文件夹：用户可以直接将文件夹拖拽到浏览器中上传
1.2改进收藏夹导入功能：现在不仅可以从Chrome和IE中导入收藏夹，还可以从火狐中导入收藏夹。从其他浏览器导入收藏夹后，新添加收藏夹会被放倒单独的文件夹中，而不是与现有的收藏夹混在一起。
1.3新的收藏夹树状视图：现在可以任意展开收藏夹，并通过拖拽更改收藏夹中项目的目录，管理更方便。
1.4下载提醒：当你关闭浏览器时，如果还有未完成的下载，则会给出提示，避免下载被中断。
1.5默认下载位置：现在可以设置默认下载位置，而不是每次下载都询问保存位置。默认下载位置设置选项在高级设置中。
***
2.原生支持Ubuntu Bash
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/dde29afbaf51f3de467c7df99ceef01f38297953.jpg)
3.全新的黑色UWP背景
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/bd0ec850f3deb48f7fa76543f81f3a292ff57853.jpg)
4.跨平台小娜提醒
5.全新的UWP版Skype APP
6.优化了通知中心
7.加入了一些全新的Emoji
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/efa594dfb48f8c54601d01b232292df5e2fe7f53.jpg)
8.全新的Connect app中，你可以不用任何硬件，将手机的Continuum体验带到电脑上来。这个程序将会支持USB链接或Wifi链接。目前这个APP只是早期体验
9.虚拟桌面改进 可以允许窗口在所有虚拟桌面上显示
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/b32ad38e8c5494ee05eccb8425f5e0fe9b257e53.jpg)
10.更新了升级界面，让他变得更加美观。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/f47beb5594eef01fccdadc58e8fe9925be317d53.jpg)
11.更新了电池设置以及省电模式设置
12.设置中，我们可以选择你的Active Hour。微软更新也会避免在这些时间段来升级你的电脑。
13.FeedBack Hub支持评论
14.锁屏Cortana微软小娜出现
15.设置Ul有变动
16.蓝屏加入了二维码
17.修复了BUG
Win10 build 14361(2016.6.3)RS1分支
1.Edge浏览器LastPass密码管理扩展：现在免费的LastPass密码管理扩展正式登陆Edge浏览器，开放下载。
2.Windows Ink改进内容：
• 现在Windows Ink直尺有足够的长度横跨Surface Book显示屏的对角线部分。
• 修复Windows Ink的铅笔工具沿直尺书写时，不能与直尺平齐的问题，还有当打开钢笔、铅笔或荧光笔弹出时，有轻微的颜色闪烁问题。
• 升级Windows Ink工作区触摸Ink按钮，使得更加醒目。
• 提升从任务量Windows Ink工作区唤出Sketchpad应用时，加载缩略图的性能表现
• 基于Insider反馈，在Sketch Pad中加入醒目的“清除所有”选项，更加醒目，还有菜单栏中的垃圾桶按钮，此前是在删除按钮下的一个选项。
3.设置提升：系统设置应用继续改进，现在导航栏窗格在亮色主题下是白色，在暗黑主题下是黑色。另外还添加了小的色彩区域，来确定你处于哪个设置页面。另外平滑性有改善，页面名称文字字体有轻微放大。界面更现代化
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/65d9b32b2834349ba88fa018c1ea15ce34d3be9c.jpg)
***
4.新的图标：在Insider版本中Win10将不断引入新的图标，现在微软已经更新了蓝光光盘图标，和其他Windows10的驱动器图标更加保持一致性。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/94de4f35349b033bf70132471dce36d3d739bd9c.jpg)
5.更新了快速操作按钮中的网络图标，显示网络飞出标识，在此前版本中使用的是通用的地球图标。 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/68c0539a033b5bb5645eee633ed3d539b400bc9c.jpg)
6.大量修复bug
7.新的加密esd机制
Win10 build 14367(2016.6.17)RS1分支
1.《反馈中心》全新键盘快捷键
打开《反馈中心》/应用中截屏：Win+F，之前的快捷键“Win+Shift+？”取消；使用Win10 Mobile手机的用户可以使用音量降低+电源键打开《反馈中心》。
2.手写地区语言支持
***
新增23个国家和地区的语言手写支持，重点是东南亚和非洲语言。开发者也可以利用这项功能在自己的应用中加入这些支持。
3.全新刷机工具
根据用户反馈，微软提供了新工具用来简单快速地实现Windows10干净安装的效果，该工具出现在设置应用，可以移除现有系统中所有已安装应用。
4.Cortana跨平台手机通知发送电脑功能更加可靠和快速，这些通知都会出现在操作中心WP组中，并且有好看的新logo。
5.操作中心快速启动开启和关闭显示不同的功能状态，便于用户区分。
6.向日语输入方式编辑器中加入新的打开/关闭隐私模式快捷键Ctrl + Shift + P，改进了日语12键键盘的宽度。
7.更新了设置中“更新和安全”的Windows更新和恢复图标。
8.修复一大堆bug
Win10 build 14372(2016.6.24)RS1分支
1.加入了新的扩展：Evernote Web Clipper（印象笔记·剪藏）。这项扩展可以帮你轻松剪切网页并且保存在印象笔记中，日后你也可以在任何设备上通过账号轻松找出这些珍藏的内容。
2.汉化优化
3.bug持续灭亡
Win10 build 14376(2016.6.29)RS1分支
1.应用商店更新（11606.1001.25），提高了性能
***
2.bug修复及提高性能
Win10 build 14379(2016.7.1)RS1分支
1.bug修复及提高性能
Win10 build 14383(2016.7.8)RS1分支
1.更多Edge浏览器扩展
2.Cortana改进
3.bug修复及提高性能
Win10 build 14385(2016.7.10)RS1分支
1.bug修复及提高性能
Win10 build 14388(2016.7.13)RS1分支
1.应用商店更新至11606.1001.39版本
2.bug修复及提高性能
Win10 build 14390(2016.7.16)RS1分支
1.亚马逊官方的浏览器拓展插件现在于Edge浏览器上可用
2.bug修复及提高性能
Win10 build 14393(2016.7.19)RS1分支1607正式版
1• 提升开始菜单、Cortana和操作中心的可靠性。
2• 可以把苹果iPod作为大容量存储设备使用。 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/1e2beab0cb134954fb60ddfa5e4e9258d0094a23.jpg)
Win10 build 14905(2016.8.18)RS2分支
只是完善了快捷键
Win10 build 14915(2016.9.1)RS2分支
1.带来了Delivery Optimization功能，能够帮助用户加快Windows更新与Windows商店应用的下载速度。 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/cb20d41d8701a18bd84220d1962f07082a38fefc.jpg)
Win10 Build 14936(2016.9.29)RS2分支
1. 新的微软Edge浏览器扩展：关灯插件、微软个人购物助手上架
2. 身份验证变化影响NAS设备和家庭文件服务器：升级到最新的预览版之后，你可能会发现家庭网络文件夹中共享设备已经消失，另外还有映射的网络硬盘也不再可用。如果你将网络设置成“私密”或者“企业”，将重新启用该功能。
3. Windows Subsystem for Linux（Windows中Linux子系统）升级：内置的Linux子系统现在可用安装Ubuntu version 16.04(Xenial)，此前最新是Ubuntu 14.04 (Trusty)。升级后用户可以安装新的实例(lxrun.exe /install or first run of bash.exe)，现有的Trusty实例不会自动升级，用户需要手动使用do-release-upgrade命令将Trusty镜像升级到Xenial。
4.简陋的UWP文件资源管理器作为彩蛋出现
***
---贴吧极速版 For UWP
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/6e29c4cd7cd98d10507042e2293fb80e79ec90b6.jpg)
Win10 Build 14946(2016.10.14)RS2分支
1.新增笔记本触摸板设置 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/e4361a1fd21b0ef4b3d9d38dd5c451da80cb3e21.jpg)
2.更新无线网络设置 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/8808a4cfc3fdfc0333a3ab6bdc3f8794a6c2267b.jpg)
***
3.输入支持更多语言
Win10 Build 14959(2016.11.4)Creators分支(代号RS2)
1.虚拟机增加显示缩放按钮
2.修复bug以及北海计划中的底层内核大一统
Win10 Build 14965(2016.11.10)Creators分支(代号RS2)
1. 用平板控制外接显示屏更简单：用户在连接到第二屏幕后，通过长按平板任务栏，然后选择“展示触控板按钮”，之后平板上就会出现一个虚拟触控板，用户可以通过该触控板对第二屏幕内容进行操作。
2.Sticky Notes更新至v1.2.9.0版本，支持了更多的语言以及快捷键
3.Windows Ink Workspace获得功能改进，量角器更易用以及出现教程
4.注册表编辑器获得改进，地址栏可以通过缩写使用
5.提升Hyper-V虚拟机的缩放体验
6.更新了迁移逻辑，从14965版本开始，用户的UAC设置以及固定到开始屏幕上的快捷方式和文件夹将会在升级后保留
7.从14965开始，按住alt+f4，会出现此窗
8.修复了14955、14959的令人蛋疼的bug
14971图享 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/fcc53b6134a85edf85602d1f40540923dc547517.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/f08aad8165380cd7459871d1a844ad345882817a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/e8279a1e4134970a10b5c3139ccad1c8a6865d39.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/e4fb2cfafbedab645d509ffcfe36afc378311ee5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/50cc3442fbf2b2115ca85672c38065380dd78e7a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/8861b642ad4bd1132b4c640e53afa40f4afb057a.jpg)
14986全新的Windows Defender 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/cd45ac124954092364606f7a9b58d109b2de499a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/150fd5fa43166d221f3a19904f2309f79152d25e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/750e81cc7b899e51f23536104ba7d933c9950d74.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/11c9419659ee3d6d197c8bcf4a166d224e4ade75.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/7627b238b6003af34e9cd0643c2ac65c1138b681.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/967cb33e8794a4c29405eb2f07f41bd5ac6e3981.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/745c39de8db1cb13fed33017d454564e93584b75.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/4fd025a6d933c895d332947fd81373f08302005e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/27fdae3c70cf3bc747bac1e8d800baa1cc112a75.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/4aa1d418ebc4b74556d8bb12c6fc1e178b82155e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/b7c2c8c279310a55a132d2f0be4543a983261090.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/3b7df9500fb30f24bd98e007c195d143ac4b03ad.jpg)
14986的3D功能 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/411d5e00213fb80eed096dd33fd12f2ebb3894cb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/6e87ecd5b31c87018a6cbee22e7f9e2f0508ffd5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/ef371e300a55b319f82d8e714aa98226cdfc17d6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/b7c2c8c279310a55a1dad2f0be4543a983261028.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/730ee58aa61ea8d334137b009e0a304e241f58f2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/5ee3ed83b9014a90eae44ab9a0773912b11beed5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/dde29afbaf51f3de1d7bb5609deef01f382979da.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/3deab51a0ef41bd54162e7f058da81cb38db3df2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/6fdade399b504fc2488bbc01ecdde71192ef6dd7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/768ebdb54aed2e73a33e8a288e01a18b85d6fad0.jpg)
14986的其他改进 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/e0186ffb513d269710b707595cfbb2fb4216d847.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/f243b7a30cf431ad42904c3d4236acaf2fdd986d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/b7c2c8c279310a55a26ad1f0be4543a983261058.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/7a075d86e950352ab0062a0c5a43fbf2b3118b40.jpg)
Win10 Build 14997 (2016.12.24泄露) Creators分支(代号RS2)【圣诞节专版】《中篇》
17.桌面日历新增农历！ 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4784663986/9da0314f9258d109b4c673d3d858ccbf6d814d9b.jpg)
19.EDGE的标签预览全面性进化！
20.新增的帮助与反馈应用
21.windows ink部分素材更改
22.自带输入法不仅支持V模式、U模式输入，还支持颜文字、表情、图片、符号输入
23.全面进化的输入法设置！
