![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/8861b642ad4bd113f42a355e53afa40f49fb05e8.jpg)
已经开发多日的Vista 8首次公开[滑稽]
【开发历史】
Build 9601
1.默认壁纸换为Build 8056壁纸
2.开始屏幕背景换为Build 8056壁纸
Build 9602
1.Aero Glass 回归，来自8400的千里相约
2.评分机制回归，最高分数9.9
3.内置针对英伟达的显卡驱动
Build 9603
1.安装程序变成奇怪的Vista式
***
Build 9610
1.代码重置，原来基于9600.17031，现在基于9600.18543，并去除了显卡驱动
2.从9602新增的特性全部消失，保留了评分机制及Vista安装背景
***
Build 9611
1.默认壁纸更换
2.开始屏幕背景更换
3.全新的绿色文件夹图标
4.Aero Glass 再次回归
***
Build 9612
？.梦幻桌面与Windows 边栏
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/141351d02f2eb93881cff59edc628535e4dd6f35.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/c7f5c68a87d6277f33e1bd5421381f30eb24fce5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/2ef27a940a7b0208c3f9b18d6bd9f2d3562cc8a4.jpg)
梦幻桌面功能在Windows 8.1无法实现
阶段：Milestone 2：Build 9612
侧边栏回归
***
阶段：Milestone 2：Build 9615
1.增加桌面小游戏2.增加两套与Vista有关的屏保3.网络图标更改为Vista式4.Ribbon变为8250样式
Build 9615严重BUG1.Aero Glass失效2.系统从已激活变为未激活状态3.侧边栏有兼容问题【不会开机启动，有时候会触发黑屏，侧边栏的关联问题】
9620将是Milestone 3版本
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/49d7ba55564e92583d9dbaba9582d158cdbf4e2a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/91acabbe6c81800aebdeb65ab83533fa838b47a4.jpg)
小游戏回归
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/4fd025a6d933c895e07da72fd81373f083020053.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/8861b642ad4bd11347ce886653afa40f4afb0553.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/222d95d2572c11dfd91d83776a2762d0f503c28f.jpg)
***
屏保的更改
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/3379ce763912b31be026f27d8f18367adbb4e115.jpg)
所以以后的版本主要目标是补完图标及设定之后，再重新开Aero Glass
9615的另外两个严重BUG[喷]
***
2.系统从已激活变为未激活状态
3.侧边栏有兼容问题【不会开机启动，有时候会触发黑屏，侧边栏的关联问题】
【开发历史】
阶段：Milestone 1：Build 9601
1.默认壁纸换为Build 8056壁纸
2.开始屏幕背景换为Build 8056壁纸
阶段：Milestone 1：Build 9602
1.Aero Glass 回归，来自8400的千里相约
2.评分机制回归，最高分数9.9
3.内置针对英伟达的显卡驱动
阶段：Milestone 1：Build 9603
1.安装程序变成奇怪的Vista式
***
阶段：Milestone 2：Build 9610
1.代码重置，原来基于9600.17031，现在基于9600.18543，并去除了显卡驱动
2.从9602新增的特性全部消失，保留了评分机制及Vista安装背景
***
阶段：Milestone 2：Build 9611
1.默认壁纸更换
2.开始屏幕背景更换
3.全新的绿色文件夹图标
4.Aero Glass 再次回归
***
阶段：Milestone 2：Build 9612
侧边栏回归
***
阶段：Milestone 2：Build 9615
1.增加桌面小游戏
2.增加两套与Vista有关的屏保
3.网络图标更改为Vista式
4.Ribbon变为8250样式
Build 9615严重BUG
1.Aero Glass失效
2.系统从已激活变为未激活状态
3.侧边栏有兼容问题【不会开机启动，有时候会触发黑屏，侧边栏的关联问题】
阶段说明：
***
Milestone 1：9601～9603
Milestone 2：9610～9615
Pre-Milestone3：9616～9620
Milestone 3：9622～9633
Milestone 4
Pre-Beta(Milestone 5)
Beta1
Beta2
RC
Pre-RTM
RTM
Windows Vista8 Build 9616
阶段：Pre-Milestone3
编译时间：2017年1月9日7点8分
详细版本：6.3.9616.0.winmain_vista8_pre.170109-0708
1.修复了关于Aero Glass的BUG
2.破解第三方主题
3.开始屏幕可定制
4.Windows 边栏从后台搬到前台
***
目前问题
1.系统为未激活状态
2.侧边栏有兼容问题【不会开机启动，可能会触发黑屏，侧边栏的关联问题】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/b227302d11dfa9ecd7727e406bd0f703908fc17a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/f9f52d91f603738d93152475ba1bb051f919ec7b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/e71ba91a9d16fdfa6c89eeb9bd8f8c5496ee7bf1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/c7f5c68a87d6277fd4bc1a6f21381f30e824fc34.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/91fdd4df9c82d158105571e6890a19d8be3e4283.jpg)
Windows 边栏从后台搬到了前台 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/4c07b0cb7bcb0a46841ca06e6263f6246a60afa4.jpg)
Windows Vista8 Build 9620
阶段：Milestone3
编译时间：2017年1月11日05：35
详细版本：6.3.9620.0.winmain_vista8_m3.170111-0535
1.新增Vista拟物元素主题2.新增梦幻桌面，点击桌面空白处会实现暂停\播放功能
3.默认主题更换为地球雪山主题
4.修复了侧边栏不会开机启动的BUG5.这是首个Milestone3 Build
***
目前问题
1.系统无法激活
2.侧边栏的关联问题
3.Vista拟物主题部分元错位
Windows Vista8 Build 9620的界面 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/0253be32c895d1439c4fda797af082025baf07a7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/68c0539a033b5bb5540b1fa43fd3d539b400bc85.jpg)
全新的拟物超级任务栏
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/2b9791256b600c3308a8e092134c510fdbf9a188.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/913cc087c9177f3e65e4c25779cf3bc79d3d5688.jpg)
拟物超级任务栏细节 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/79f5463eb80e7bec912a3dbb262eb93899506be9.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/990db02b6059252d43d7235e3d9b033b59b5b999.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/5b21ca6fddc451da9e2233b1bffd5266d216328c.jpg)
gif怎么不动[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/47fc4f391f30e924e32eb86b45086e061f95f7d3.jpg)
win8.1怎么强制激活
Windows Vista8 Build 9625
阶段：Milestone3
编译时间：2017年1月12日04：30
详细版本：6.3.9625.0.winmain_vista8_m3.170112-0430
1.全新的开始屏幕布局2.修复了Vista拟物主题错位的BUG3.修复了侧边栏的关联问题4.侧边栏默认在其他窗口的顶端5.记事本的默认字体改为微软雅黑6.默认壁纸换为Build 8148自然风貌壁纸目前问题1.系统无法激活2.控制面板左侧栏空白，点击才会显示字
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/f1c154fb828ba61e90f537744834970a314e5943.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/16baf559d109b3deb1191b33c5bf6c81810a4c38.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6e29c4cd7cd98d100058f36a283fb80e79ec90d6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/50cc3442fbf2b21178d67a15c38065380ed78ee3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/b6f7148ca97739123c8d7a3af1198618377ae23c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/150fd5fa43166d22f15cebcf4f2309f79152d2bc.jpg)
记事本的默认字体改为微软雅黑 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/d9d1db305c6034a87c8c46dac213495408237670.jpg)
BUG：控制面板左侧栏空白，点击才会显示字 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/97de0758252dd42af072fff00a3b5bb5c8eab86c.jpg)
默认壁纸换为Build 8148自然风貌壁纸的其中之一 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6d0187ff9925bc317c98ffc357df8db1c913709d.jpg)
明天会编译出Milestone3的最终版本，因为下个阶段是Milestone 4
***
这两个BUG，请你们提出怎么解决
1.系统无法激活
2.控制面板左侧栏空白，点击才会显示字
Windows Vista8 Build 9626阶段：Milestone3编译时间：2017年1月13日05：32详细版本：6.3.9626.0.winmain_vista8_m3.170113-05321.性能优化2.Milestone3的最后一个Build，即将公开发布镜像目前问题1.系统无法激活2.控制面板左侧栏空白，点击才会显示字
Windows Vista8 Build 9630
阶段：Milestone 4
编译时间：2017年1月25日17：06
详细版本：6.3.9630.0.winmain_vista8_m4.170125-1706
1.解决了激活问题
2.系统体积缩小为8.4G左右
3.大部分功能因重组而丢失，仅保留Vista图标元素
4.默认禁止WU和UAC
5.采用全新默认壁纸 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/ef371e300a55b319cede903a4aa98226cefc174a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/eb90644e78f0f7368e825e4e0355b319eac41371.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/e1b0ca355982b2b749e32b8b38adcbef77099b72.jpg)
预计全部功能会在2月前全部回归
Windows Vista8 Build 9631
阶段：Milestone 4
编译时间：2017年1月25日18：40
详细版本：6.3.9631.0.winmain_vista8_m4.170125-1840
1.新增节能屏保
***
2.部分功能回归 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/8c4b0b80800a19d803b68f4a3afa828ba71e4639.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6e87ecd5b31c870187c9b9a92e7f9e2f0608ff73.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/035de527cffc1e179e0a877e4390f603728de939.jpg)
Windows Vista8 Build 9635
阶段：Milestone 4
编译时间：2017年1月29日22：00
详细版本：6.3.9635.0.winmain_vista8_m4.170129-2200
1.梦幻桌面回归，但默认不启动
2.节能屏保为默认屏保，等待时间为5分钟
3.新增5384小工具
4.aeroglass回归，但是变成了可选组件
5.桌面放上了激活工具
6.Vista示例已全部增加
7.Vista功能基本开发完成
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/4903f7539822720e602ef34972cb0a46f01fab92.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/94de4f35349b033bda94ec691cce36d3d439bd5e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/92ef69f51bd5ad6edfe6745988cb39dbb7fd3c5e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/1e2beab0cb134954c4c3f9d75f4e9258d3094a9d.jpg)
Windows Vista 8 Build 9638
阶段：Milestone 4编译时间：2017年1月30日09：48详细版本：6.3.9638.0.winmain_vista8_m4.170130-09481.默认字体改为微软雅黑细体
2.节能屏保等待时间为10分钟3.新增RP主题，而且是默认主题，与Vista拟物主题共存
4.Vista拟物主题更拟物，控制面版绿色左侧栏回归，系统属性图片更好看
5.内置OldNewExplorer1.1.8.2
6.Milestone 4的最后一个Build，即将公开发布镜像
***
目前问题1.9638有引导问题，，所以在PE下安装之后，请修复引导再重启
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/e0186ffb513d2697fad7ddee5cfbb2fb4216d877.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/a00afe24bc315c60388bbe5c84b1cb1348547758.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/a9d0df98a9014c08e118fd16037b02087af4f45c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/9da0314f9258d109a5c07c01d858ccbf6d814d53.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/25cc6bd6912397dd7d764db75082b2b7d1a28768.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/4c0056accbef7609ae7f4c2c27dda3cc7dd99e07.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/0f36b2638535e5dd1116736c7fc6a7efcf1b6245.jpg)
RP主题与Vista拟物主题那个你们更喜欢！
简化阶段说明：
***
Milestone 1：9601～9603
Milestone 2：9610～9615
Pre-Milestone3：9616～9619
Milestone 3：9620～9626
Milestone 4：9630～9638
Pre-Beta1
Beta1(仅一个)
Pre-Beta2
Beta2(仅一个)
Pre-RC
RC(仅一个)
Pre-RTM
RTM(仅一个)
SE(不确定会出)
Windows Vista 8 Build 9641
阶段：Pre-Beta1
编译时间：2017年2月4日10：00
详细版本：6.3.9641.0.winmain.170204-1000
***
1.用户配置文件统一
2.加入媒体中心
3.集成微软拼音新体验2012
4.开始图标底层修改
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/f1c154fb828ba61eda416d954834970a324e59d6.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/d17bc7ed08fa513dd4d6c964346d55fbb3fbd906.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/891e72cf36d3d539ac2fab793387e950342ab06b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/f08aad8165380cd7b84c0657a844ad345882812b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/4a2505d8f2d3572cf6e938668313632763d0c373.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/97de0758252dd42a3ab5a5110a3b5bb5cbeab8c5.jpg)
骂得真狠[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/ab30d04443a9822670a28f9d8382b9014b90eb1b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/07e4de13c8fcc3ce49a26d899b45d688d53f201b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/7159acee76094b369903bf57aacc7cd98f109de8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/39c56d54b319ebc40b97d2238b26cffc1c171696.jpg)
win8.0样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6e87ecd5b31c870173ba155c2e7f9e2f0608ff76.jpg)
win8.1样式
Windows Vista 8 Build 9648
阶段：Pre-Beta1
编译时间：2017年2月5日11：00
详细版本：6.3.9648.0.winmain.170205-1100
1.使用Start8以支持编辑开始图标
2.砍掉了大部分预装应用
3.打开多程序文件夹没有崩溃卡死现象
4.关于的2013改为了2017
5.注册表编辑器使用了Build 10558的图标
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/99c7af94d143ad4bcd05527c8b025aafa50f0653.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/c7b08cf91a4c510fa4ecf6a66959252dd52aa553.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/e9835e13b31bb051c201a7943f7adab44bede05e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/3b1833e636d12f2e0b57badc46c2d56284356835.jpg)
***
目前BUG
1.Start8开始菜单错位严重
2.剩下的照片、相机应用闪退
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/141351d02f2eb938295f6d4edc628535e4dd6f55.jpg)
win8.1样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/1b41aeeb15ce36d35d27948c33f33a87e850b164.jpg)
经典样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/3c2dea1101e939018a219a8272ec54e737d19664.jpg)
小7样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/4cc7e045ebf81a4c2a3afb75de2a6059242da673.jpg)
大7样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/e3381bd88d1001e9931f03b3b10e7bec55e79764.jpg)
华丽8样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6d0187ff9925bc319540162457df8db1ca137066.jpg)
标签样式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/97de0758252dd42aa90316170a3b5bb5c8eab87d.jpg)
科幻样式
Windows Vista 8 Build 9651
阶段：Pre-Beta1
编译时间：2017年2月6日09：30
详细版本：6.3.9651.0.winmain.170206-0930
1.【激活软件】HEU换成了KMSpico
2.其他细节改进
3.优化了配置 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/ebecf02ad40735fa4bdffd0497510fb30e240851.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/68c0539a033b5bb5e8d093433fd3d539b700bc79.jpg)
Windows Vista 8 Build 9665
阶段：Pre-Beta1
编译时间：2017年2月9日11：20
详细版本：6.3.9665.0.winmain.170209-1120
1.集成7z压缩软件16.04
2.加入墨球(显光标)
3.加入Windows Live Mail
4.加入功能强大的照片库和影音制作
5.所有UWP应用回归
6.开始屏幕改为不违和的黑色背景
7.Ribbon的蓝色按钮改为空格
8.砍掉BUG巨多的开始菜单
***
目前BUG
第三方主题失效
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/06d76ef6905298223d904c61deca7bcb0846d4e2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/730ee58aa61ea8d33ef701a69e0a304e271f58b4.jpg)
Windows Live Mail 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/a7e5f7ee76c6a7ef5206dc84f4faaf51f2de6661.jpg)
开始屏幕改为不违和的黑色背景 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/eb90644e78f0f736a81238a30355b319e9c4139c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/d2acb608b3de9c8267db8e2d6581800a1bd843cf.jpg)
Ribbon的蓝色按钮改为空格 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/f8fa1ced54e736d1bf5cfbaa92504fc2d462693e.jpg)
加入功能强大的照片库和影音制作 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/d41a971e3a292df545cbdab7b5315c6035a87379.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/13b79cf3b2119313c49a88126c380cd793238da8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/7625482fb9389b50dc7297f08c35e5dde5116efc.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6e87ecd5b31c87018325c5442e7f9e2f0508fff2.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/a6391c889e510fb3fad70035d033c895d3430cbf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6e87ecd5b31c87018097c4442e7f9e2f0608ff60.jpg)
Windows Vista 8 Build 9672
阶段：Beta 1【官方Beta 1】
编译时间：2017年2月13日16：00
详细版本：6.3.9672.0.winmain_vista8_beta1.170213-1600
1.第三方主题失效问题已修复
2.新的安装界面背景
3.默认使用Vista式任务栏
4.配置文件统一
5.一些细节修改以及体积缩小
6.首次使用ISO格式
ESD：2.7G
ISO：3.4G
展开体积：8～12G左右
***
目前BUG
1.可能出现Modern 应用全崩问题
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/79f5463eb80e7bec92803c48262eb9389a506b32.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/8de5158a4710b912c7ddc957cafdfc039345226b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/3deab51a0ef41bd5b160d75d58da81cb38db3d58.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/90e26e25ab18972bf3673f63efcd7b899f510a2a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/42fc1cf50ad162d99eeb5db518dfa9ec8b13cd03.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/cde466e83901213f7c3971755de736d12e2e9502.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/8de5158a4710b912c76ec957cafdfc03904522e4.jpg)
Windows Vista 8 Build 9674
阶段：Pre-Beta2
编译时间：2017年2月23日04：20
详细版本：6.3.9674.0.winmain.170223-0420
***
1.模拟出了效果较差的Flip 3D特效【由于截不了图，所以用14393的图】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/7627b238b6003af3df7e21f93c2ac65c1238b65d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/01c0f00b304e251fd52f1961ae86c9177d3e5340.jpg)
***
2.Vista示例素材基本完善
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/d729c645ad3459824430190b05f431adc9ef84e3.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/cae7042662d0f70324bc694501fa513d2797c517.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/2ef27a940a7b0208d16cc3786bd9f2d3552cc8fc.jpg)
***
3.【激活软件】KMSpico换回HEU
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/4c07b0cb7bcb0a46399077a06263f6246960afeb.jpg)
***
4.安装界面完美仿V！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/90e26e25ab18972bbcd8fc53efcd7b899c510aba.jpg)
***
BUG：Flip 3D特效组件兼容性较差
Windows Vista 8 Build 9680
阶段：Pre-Beta2
编译时间：2017年2月24日01：31
详细版本：6.3.9680.0.winmain.170224-0131
***
1.启动界面替换成了win8.1 build 9431 betta鱼界面
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/efa594dfb48f8c543a2bc6b433292df5e2fe7fa2.jpg)
***
2.原来的蓝色按钮回来了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/1292b7170924ab186d5be2ac3cfae6cd79890bd5.jpg)
***
3.winver图片更符合初衷
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/50cc3442fbf2b211ec6086d5c38065380ed78ed0.jpg)
***
4.状态栏图标替换为Vista式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/ab0c7d4d510fd9f9bec656f22c2dd42a2a34a449.jpg)
***
5.新的魔幻填字游戏壁纸
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6e87ecd5b31c87018ca0b07d2e7f9e2f0608ff08.jpg)
***
6.加入Vista logo发光屏保
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/6050212209f79052cf6645a505f3d7ca7acbd521.jpg)
9680的界面
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/bb06d5109313b07e4af8529305d7912395dd8cdd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/f3ed8cc5b74543a99a68f85717178a82b801142a.jpg)
Windows Vista 8 Build 9682
阶段：Pre-Beta2
编译时间：2017年2月25日15：00
详细版本：6.3.9682.0.winmain.170225-1500
1.任务栏的默认换回超级任务栏，当然你们可以设置老式任务栏
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/13b79cf3b2119313db23812d6c380cd793238dc4.jpg)
***
2.加入大量壁纸包
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/141351d02f2eb93812e5046fdc628535e7dd6f9c.jpg)
***
3.更多扁平元素换成拟物元素
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/d8d6150f0cf3d7ca3c0641ebfb1fbe096963a9b4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/90e26e25ab18972b32bf7e57efcd7b899c510a9f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/3379ce763912b31bbf27b3b48f18367ad8b4e1dd.jpg)
***
4.加入PCS以替代限速的度娘云
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/8eeffa17fdfaaf516562ff22855494eef21f7a9b.jpg)
***
5.Flip 3D特效和开始菜单作为可选组件加入
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/4c23f62297dda144dfe7122fbbb7d0a20ef486b2.jpg)
Windows Vienna Blue Build 9685
阶段：Pre-Beta2
编译时间：2017年2月26日02：00
详细版本：6.3.9685.0.winmain.170226-0200
***
1.宣布Windows Vista 8改名为Windows Vienna Blue
2.加入Vista的阳光/反射特效
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/8a7402390cd79123bb3e2eeaa4345982b0b78043.jpg)
***
3.优化了主题并加入Windows 8 Build 8056的隐藏主题-自然
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/b2ebd9086b63f62463649c9d8e44ebf81b4ca36c.jpg)
Vista拟物效果
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/b828b601baa1cd11f401d7beb012c8fcc1ce2dea.jpg)
Windows 8 RP效果 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/2b946b328744ebf811ffc0a1d0f9d72a6259a793.jpg)
Windows 8.1默认效果 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/035de527cffc1e17484b29af4390f603718de9aa.jpg)
Windows Vienna Blue Build 9689
阶段：Pre-Beta2
编译时间：2017年2月27日02：25
详细版本：6.3.9689.0.winmain.170227-0225
***
1.winver图片再次更改
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/0f36b2638535e5dd61f2c35f7fc6a7efcc1b624d.jpg)
***
2.任务栏默认显示触摸键盘
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/32fa6bf2d7ca7bcb344aa7afb7096b63f724a876.jpg)
***
3.加入大量经典屏保
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/edc03e83b2b7d0a2611f651dc2ef760949369a55.jpg)
***
4.一些令人激动的细节更改
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/9a402dec2e738bd4b819d0b1a88b87d6267ff96f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/89e3183f6709c93dca6d6e77963df8dcd300548c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/ca76de004a90f603727bfcc73012b31bb251ed58.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/ab30d04443a9822634894ba78382b9014890ebd8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/d3e7d77fca8065386862c4939edda144af34829f.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/b32ad38e8c5494ee60f26f9924f5e0fe9b257e57.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/edbfb61273f08202b142f1bf42fbfbeda9641b57.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4925693470/65ebf2cbd1c8a7867f882a8e6e09c93d72cf5081.jpg)
Windows Vienna Blue Build 9700
阶段：Beta2【官方Beta 2】
编译时间：2017年3月3日10：47
详细版本：6.3.9700.0.winmain.170303-1046
***
1.经典屏保完善，并出现了怀旧主题
2.WinVer再次更换
3.加入开始菜单和Vista式开始按钮(开始屏幕保留)
4.许可条款更换
***
已知BUG
Metro 应用仍然全崩
不能激活问题已经确定【其实Beta 1也不能激活】
网络名称显示2
Windows Vienna Blue Build 9711
阶段：Omega
详细版本：6.3.9711.0.winmain.170323-1635
1.内核升级至9600.17415
2.这台电脑更名为计算机
3.右上角三个按钮缩小
4.媒体中心及多余屏保被去除，独立至单独的美化包
***
已知问题
Aero无法启用(1.2.5不兼容9600.17415)
Aero无法启用已解决，但无法去除水印和弹窗
Windows Vienna Blue Build 9715
阶段：Omega
详细版本：6.3.9715.0.winmain.170329-1700
1.添加益达两款游戏
已知问题
有水印弹窗(无解)
