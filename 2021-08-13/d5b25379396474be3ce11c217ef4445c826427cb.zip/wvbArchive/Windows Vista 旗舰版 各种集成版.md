本镜像集成：
1.截至2017.1.14的所有补丁
2.Internet Explorer 9及最新补丁
3.DirectX 11
4.部分Windows Ultimate Extras
(1).Windows Dreamscene
(2).Microsoft Tinker
(3).声音方案：Ultimate珍珠&Ultimate水晶（声音方案由于特殊性，首次进桌面才部署，需管理员权限确认）
注意，镜像为64位版，大小4.9GB
mega地址：m[滑稽]ega.n[滑稽]z/#!bgMXAKAD!WwLIewcbEyAX6y8XBMN-RMPU9lBfFDiwfRS-vSFDbbw
百度盘正在极其缓慢的上传[喷]
@longhorn4093 申精
优化内容和上次一样
优化：
1.桌面默认存在计算机图标
2.默认显示文件扩展名
3.explorer在不同进程中打开
4.（经典及最小化时）显示完整文件夹路径
5.不参加客户体验报告计划
大家说，接下来做什么版本？
1.business x64
2.business x86
3.ultimate x86
4.enterprise x86
家庭版稍后考虑
度盘上传已放弃
