回帖事情详细注明要下载的系统版本，软件之类的也要详细版本。
例：Microsoft Windows XXX Build XXXX
@Longhorn4093 求加精[滑稽]
顶
