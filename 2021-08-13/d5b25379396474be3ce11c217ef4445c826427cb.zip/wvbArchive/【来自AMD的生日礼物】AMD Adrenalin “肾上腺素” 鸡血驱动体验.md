﻿2017年12月12日，在lz生日的当天[滑稽]，AMD发布了最新一代鸡血驱动——AMD Radeon Software Adrenalin Edition，取代了之前的Crimson Relive Edition。让我们一起来见识一下amd的鸡血驱动有多鸡血[滑稽]
为了对比，lz准备了2个驱动，一个是最末代的crimson relive驱动，也就是上一版本的驱动
版本号：17.11.4，编译日期：2017年11月27日
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/90566bf531adcbef3313368aa7af2edda2cc9f08.jpg) 
***
另一个就是我们今天的主角，全新的Adrenalin驱动
版本号：17.12.1，编译日期：2017年12月11日
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/4c0056accbef76090d2cd11325dda3cc7dd99e08.jpg) 
***
话说amd官网驱动下载页还是写着crimson relive[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/7159acee76094b36ebb55361a8cc7cd98c109d08.jpg)
***
常言道：直播必吃饭[滑稽] 饭后继续
好了lz回来了[滑稽]
从生命科学的角度来说，肾上腺素可以使人心跳加快、血压升高、呼吸加快、血糖浓度升高。。。咳咳，不好意思扯远了[笑眼] 这次amd的驱动改名为肾上腺素，是否也能带来激动人心的体验呢？一切当然要测试一下才能知道了[滑稽]
测试平台：
华硕X99 A-II
Intel Xeon E5 2620 V4
32GB Kingston Fury X DDR4 2133MHz 四通道
AMD Radeon RX 480 8GB 蓝宝石超白金
测试项目：
（鉴于我游戏玩的不多，只有几款能测试了）
Grand Theft Auto V
Minecraft（光影&原版）
Cinebench
3DMark
稍后开测
***
为保证结果精准，首先使用AMD Clean Uninstall工具清理现有驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/d41a971e3a292df5a9ca0499b7315c6035a87322.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/a529801090ef76c69a6953a79616fdfaad5167fc.jpg)
***
安装驱动，首先测试的是Radeon Software Crimson Relive Edition 17.11.4
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/8be72e550923dd5405050ce4da09b3de9d824839.jpg) 
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/141351d02f2eb938aa0fee7ede628535e7dd6fd5.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/b7c2c8c279310a551b554a78bc4543a98326103a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/39c56d54b319ebc41d09e2158926cffc1f17163a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/112ee6ca39dbb6fddbec71aa0224ab18952b37f8.jpg)
***
首先测试的是Grand Theft Auto V
除MSAA相关的“A黑选项”外全部开最高，先测试2560x1440分辨率，再测试1920x1080分辨率，均为全屏模式
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/95cdd1013af33a87e1479196cd5c10385243b50d.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/a6391c889e510fb39df1e11bd233c895d3430c43.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/3b7df9500fb30f24d1727a8fc395d143af4b0343.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/39c56d54b319ebc41f84e0158926cffc1c1716b7.jpg)
***
GTA V 2560x1440 Crimson Relive 17.11.4驱动
5个场景平均帧率：47.4564348 FPS
5个场景最高帧率：64.7033684 FPS
5个场景最低帧率：24.0764066 FPS
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/730ee58aa61ea8d3a47ae9889c0a304e271f58d3.jpg)
***
GTA V 1920x1080 Crimson Relive 17.11.4驱动
5个场景平均帧率：48.4900932
5个场景平均最高帧率：67.9773008
5个场景平均最低帧率：32.023668
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/61cbdf0f7bec54e712d48492b2389b504ec26a73.jpg)
***
Cinebench R15 OpenGL Crimson Relive 17.14.11驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/bb06d5109313b07e3758dd8407d7912395dd8c4f.jpg)
***
明天继续测试
Minecraft 1.12.2 无光影 2560x1440
画质全高，默认材质
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/f243b7a30cf431ad56eb52b44036acaf2fdd9873.jpg) 
***
测试我自己制作的一小段轻轨地图，在场景较复杂的车库内，平均fps在30左右
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/8861b642ad4bd1136bfea6bf51afa40f4afb0504.jpg) 
***
在轨道较复杂的部分，平均fps在45左右
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/c2f63daea40f4bfbe6b98fd9084f78f0f53618c2.jpg) 
***
在场景比较简单的部分，平均fps在60左右
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/fcc53b6134a85edf4512efae42540923df547592.jpg) 
***
不过明显觉得mc没能好好利用多线程。。。可能cpu也有瓶颈吧
***
接下来是Minecraft 光影测试 版本 1.10.2，2560x1440，设置如图
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/4e007cd4ad6eddc451f2a77632dbb6fd5366331e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/f243b7a30cf431ad50a550b44036acaf2fdd9839.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/90566bf531adcbefea436d8ba7af2edda2cc9f39.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/1c9453a95edf8db10c736fe90223dd54544e74d7.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/66633eef3d6d55fbecc165ab66224f4a21a4dd29.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/f6f45df23a87e950b210e0e11b385343faf2b429.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/a9a4522bc65c1038d979dd4fb9119313b17e8929.jpg)
***
对了，还有材质包
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/9da0314f9258d1097ee4bb3fda58ccbf6d814d29.jpg)
***
Minecraft 1.10.2 with shaders 2560x1440 crimson relive 17.11.4驱动
同样的场景，成绩可以说是惨不忍睹了，全部在10fps左右[狂汗]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/746f643a5bb5c9ea69551c6ede39b60038f3b38a.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/65ebf2cbd1c8a78616d155836c09c93d72cf50bd.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/38049037afc3793114c999a4e0c4b74541a9118a.jpg)
***
多加一个测试项目：AIDA64 GPGPU Benchmark 理论性能测试 crimson relive 17.11.4驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/512bceed8a1363272e73d9be9a8fa0ec0afac792.jpg)
***
3DMark Time Spy DirectX 12 基准测试 Crimson Relive 17.14.11驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/d1d7f0dca144ad34dd348a0adba20cf433ad85ad.jpg)
***
3DMark Fire Strike 1080p 测试 crimson relive 17.11.4驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/fcc53b6134a85edf229ef6ae42540923dc547526.jpg)
***
3DMark Fire Strike Extreme 1440p 基准测试 crimson relive 17.11.4驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/fa55aa10728b47106fbb8841c8cec3fdfe032398.jpg)
***
3DMark Fire Strike Ultra 4K 基准测试 crimson relive 17.11.4驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/e1b0ca355982b2b7abbc4f493aadcbef77099b15.jpg)
***
3DMark API开销 功能测试 720p crimson relive 17.11.4驱动
虽然这个测试不适合用来测试不同显卡的性能，但是非常适合比较不同驱动、软件对性能的优化能力
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/1292b7170924ab187f7c92ba3efae6cd79890bce.jpg)
***
3DMark API开销 功能测试 1080p crimson relive 17.11.4驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/43bb1ff1f736afc386ad42e8b819ebc4b545128b.jpg)
***
3DMark API开销 功能测试 1440p crimson relive 17.11.4驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/e0186ffb513d2697604c75d05efbb2fb4116d891.jpg)
***
3DMark API开销 功能测试 4K crimson relive 17.11.4驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/8b1b11084b36acaf55dde97177d98d1000e99c77.jpg)
***
莫非大家都吃饭去了[狂汗]
好了现在开始测试新版驱动的性能
依然使用clean uninstall utility清理当前驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/6e29c4cd7cd98d10776d6abc2a3fb80e79ec90f3.jpg)
***
安装完成！
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/768ebdb54aed2e73830ce4a18c01a18b85d6fa4f.jpg) 
***
gpu-z
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/7b33f83cf8dcd10001689aac798b4710bb122fb8.jpg)
***
多了很多选项
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/c2d2a8fd1e178a8241f6132dfd03738dab77e86f.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/d729c645ad345982d656891f07f431adc9ef8450.jpg) 
可以在这里登录平台进行直播
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/0f36b2638535e5dd9a56ca527dc6a7efcf1b623e.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/7a738e51352ac65c452509fef0f2b21192138a14.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/75dea15d10385343acefe8ac9813b07ecb808814.jpg)
***
手机端的amd link 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/75dea15d10385343afa4efac9813b07ec88088cd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/91fdd4df9c82d15856e9313c8b0a19d8be3e42cd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/512bceed8a1363277f40aabe9a8fa0ec0afac787.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/5d616d7a02087bf41f863f64f9d3572c13dfcfce.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/d9d1db305c6034a8d04fd00cc01349540b237687.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/b7c2c8c279310a555f89b679bc4543a980261087.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/23d305d1f703918f807d55475a3d26975beec480.jpg)
GTA V 1440p Adrenalin 17.12.1驱动
5个场景平均帧率：45.7958046
5个场景平均最高帧率：70.4208238
5个场景平均最低帧率：31.3138134
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/e71ba91a9d16fdfadb5a9963bf8f8c5495ee7b7a.jpg)
***
GTA V 1080p Adrenalin 17.12.1驱动
5个场景平均帧率：46.6317788 FPS
5个场景平均最高帧率：72.418596 FPS
5个场景平均最低帧率：30.2197662 FPS
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/66633eef3d6d55fbabc228ab66224f4a21a4dd28.jpg)
***
Cinebench R15 OpenGL Adrenalin 17.12.1驱动
成绩居然变差了[惊哭]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/43bb1ff1f736afc3a07764e8b819ebc4b645123d.jpg)
***
Minecraft 1.12.2 无光影 2560x1440
发现最低帧率还是那样，但是最高帧率有所提升，浮动的比较厉害
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/b32ad38e8c5494ee82664b9426f5e0fe9b257ee8.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/f08aad8165380cd7d67ce660aa44ad345b8281d6.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/d41a971e3a292df595a1e898b7315c6036a873d6.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/75dea15d10385343bb4ac3ac9813b07ec88088af.jpg)
***
又要吃饭了[滑稽]
Minecraft 1.10.2 with shaders 2560x1440 adrenalin 17.12.1驱动
带了光影之后还是老样子 该怎么差还是怎么差[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/c760c3c37d1ed21ba9276068a66eddc453da3f42.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/42fc1cf50ad162d90b032c911adfa9ec8813cd40.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/68cc7831e924b899599d37b565061d95087bf694.jpg)
***
AIDA64 GPGPU Benchmark 理论性能测试 Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/9596e234e5dde711cae6087bacefce1b9c166178.jpg)
***
3DMark Time Spy DirectX 12 基准测试 1440p Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/7a738e51352ac65c3fc7d3fef0f2b21191138a76.jpg)
***
3DMark Fire Strike 1080p 基准测试 Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/7a738e51352ac65c3c06d0fef0f2b21192138a35.jpg)
***
3DMark Fire Strike Extreme 1440p 基准测试 Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/6e29c4cd7cd98d10453ebcbc2a3fb80e79ec904e.jpg)
***
3DMark Fire Strike Ultra 4K 基准测试 Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/0a649102738da977f7d43ba6bb51f8198418e3be.jpg)
***
3DMark API开销 功能测试 720p Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/d17bc7ed08fa513dd0acd353366d55fbb3fbd92b.jpg)
***
3DMark API开销 功能测试 1080p Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/91acabbe6c81800a760f3783ba3533fa808b474e.jpg)
***
3DMark API开销 功能测试 1440p Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/e1b0ca355982b2b7e1c381493aadcbef74099bd0.jpg)
***
3DMark API开销 功能测试 4K Adrenalin 17.12.1驱动
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/49d0cc19972bd4079725687070899e510db30956.jpg)
***
总结：
这次的驱动更新更多的是带来新的功能，性能上的提升比较少，不过这也不奇怪，这驱动距上一版本也才16天罢了
附上对比图表
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/f243b7a30cf431add7e7d3b44036acaf2fdd987f.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/6e87ecd5b31c87011ccc226b2c7f9e2f0608ff3f.jpg) 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5480007730/c7f5c68a87d6277f5e68a2b523381f30e824fc3f.jpg)
***
====完====