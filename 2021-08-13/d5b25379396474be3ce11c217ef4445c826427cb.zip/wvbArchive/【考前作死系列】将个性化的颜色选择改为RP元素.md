`themecpl.dll`与`themeui.dll`都经过了一些修改之后，
效果如下：

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5642418323/5b21ca6fddc451da2409b88ebafd5266d21632c9.jpg)

![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5642418323/480e363c269759ee3df4d4aebefb43166c22df20.jpg)

这也证明了只要想定制，只要微软没写签名保护，还是可以定制你想要的系统外观的。
就是可惜了，`Shell32.dll`被写了签名保护，软件警告只要修改就无法被系统加载识别。

/s/1yB![img](https://tb2.bdstatic.com/tb/editor/images/face/i_f06.png?t=20140803)SR5D![img](https://tb2.bdstatic.com/tb/editor/images/face/i_f06.png?t=20140803)YCISfh![img](https://tb2.bdstatic.com/tb/editor/images/face/i_f06.png?t=20140803)Pm59b![img](https://tb2.bdstatic.com/tb/editor/images/face/i_f06.png?t=20140803)aUWag
