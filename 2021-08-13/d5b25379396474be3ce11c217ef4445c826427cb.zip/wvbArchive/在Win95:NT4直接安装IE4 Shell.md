有这个方法，就不用先装IE4获取桌面更新后再升级到IE5/6了，非常简单
1.找到IE的最新安装包，95最高5.5 SP2，NT4最高6 SP1（5.5 SP2的安装文件已上传）
2.解压ie4shl95.cab或ie4shlnt.cab到某个目录下，对应好系统，千万别搞错！
3.正常安装IE，安装好后别急着点完成重启！先完成后面的
4.在ie4shl95/nt.cab的解压目录找到ie4shell.inf,右击安装
5.安装过程会出现一次找不到文件，直接跳过
6.现在可以重启了，但还没完！
7.重启后注册webvw.dll和ie4tour.dll，完成！
IE 5.5 SP2 CHS完整版：95/NT4下完全安装没问题，这东西太稀有了！
链接：![](http://pan.baidu.com/s/1eRVxJjk 密码：zwld
IE6 公众预览计划：
链接：![](http://pan.baidu.com/s/1qXNBPoC 密码：6ix5
文件全，很多软件附带的这个版本没有NT4的安装文件
补充：那个出错的文件是wallpapr.htm，如果需要可以自己复制到%windir%\web\wallpaper目录下替换
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5195962591/e9835e13b31bb051bf4c95883c7adab44bede01f.jpg)
