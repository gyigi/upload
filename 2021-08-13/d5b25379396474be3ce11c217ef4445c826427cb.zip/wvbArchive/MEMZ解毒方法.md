如题，如果你家电脑不幸感染了MEMZ，这以下几种办法能快速让你的电脑恢复正常[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5053801730/92ef69f51bd5ad6eeccba73688cb39dbb7fd3c35.jpg)
==轻度中毒==
如果你的电脑触发MEMZ时间不到3分钟，那么你可以在它销毁你硬盘所有数据前结束它并修复。
做法:
同时按下Windows+R，呼出运行窗口。
在输入框中输入taskmgr运行任务管理器。
找到进程，结束任意一个MEMZ.EXE
随后电脑蓝屏。
在闪过OEMLOGO的一瞬间按下BIOS热键，进入BIOS。
插入Windows安装盘，随后选择CD-ROM启动/USB-HDD启动(条件是U盘已格式化为USB-HDD启动模式)
在启动的安装程序中点击“下一步”，会看到一个界面，点击左下角的修复计算机(R)，进入Windows RE恢复环境。
在弹出的窗口中选择“命令提示符”/选择“高级选项”，在新界面中选择“命令提示符”。
进入CMD环境后，输入指令:bootfix /fixmbr
bootfix /fixboot
然后两个命令都提示操作成功之后选择重新启动，在BIOS内修改Boot项为Hard Disk，从硬盘启动。
修复完毕。
==重度中毒==
如果你的电脑桌面已经变成了一条无限重叠的隧道，那么请先强制重启计算机，热重启拔掉电源都可以。
随后重启，插入Windows安装光盘。
在安装程序中选择下一步，然后选择“现在安装”。
进入Windows PE预安装环境，阅读许可条款，输入产品密钥后在弹出的安装方式选择界面中选择“自定义”。
将未分配磁盘格式化。
选择刚才格式化的磁盘进行安装。
等待安装结束。
系统重装完毕，这是目前最简单的对付MEMZ重度中毒的方法了。
==无可救药==
我有一台电脑，戴尔灵越魔方11MF-3000，开机是没有BIOS提示的，我不知道该如何进入BIOS。
后来，我把这台电脑拆机，把硬盘卸下并安装到我的主力机，把硬盘格式化了。
随后，我运行WinNTSetup，将OEM版镜像安装到了那台电脑的硬盘。
卸载硬盘驱动，将硬盘从电脑上拆除并接入中毒主机。
启动后进入OOBE阶段，完成配置后即可正常使用。(应该没有比我这还要奇葩的电脑了吧)
这个帖子来自微软社区:https://answers.microsoft.com/en-us/protect/forum/protect_other-protect_scanning/memz-malwarevirus-trojan-completely-destroying/268bc1c2-39f4-42f8-90c2-597a673b6b45
今天回去测试一下5楼楼中楼的方法
