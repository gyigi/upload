为什么就一个艾特，直接让一个吧瞬间人数翻了一倍？
这究竟是人性的扭曲还是道德的沦丧？？？
让我来为你们讲解这段BLACK HISTORY吧[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765594907/c7f5c68a87d6277ff26efb9f20381f30e824fc0b.jpg)
***
Win7 Beta镇楼[滑稽]
【开端】
【2016年9月3日 13:24，吧友@喜羊羊441 发表“Vista吧已经覆灭”的贴子，http://tieba.baidu.com/p/4764906222（真—导火索）】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765594907/09a06e22dd54564e62a6d491bbde9c82d3584f48.jpg)
***
（如图5）
【于是诸多原vista吧吧友加入了windows__vista吧】
【2016年9月3日 13:38，http://tieba.baidu.com/p/4764924030，吧友@焊锡补牙 要求撤销吧主AS的vista吧吧主】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765594907/49d7ba55564e925820f7b6469482d158cebf4e48.jpg)
***
（如图6）
【还是同一天13点—14点左右，吧主AS开始对一些吧友进行封禁】
【还是同一天 13:51，vista吧吧主@AS4837 发表了一样标题的主题贴，矛头直指windows__vista吧的吧务，并且将此贴置顶，之后设为今日话题（其实AS在windows7吧处理一些小白、乱封乱删、正常封删的时候经常这么做的。然而我认为两吧吧情本身不同）】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765594907/9da0314f9258d1094120991ad958ccbf6e814d48.jpg)
***
（如图7）
【还是同一天，14点—18点，vista吧被爆吧，随后AS对爆吧人员直接封禁】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765594907/16baf559d109b3de6f7cd4c0c4bf6c81820a4c48.jpg)
***
（如图8）
【补充】
【还是同一天 14点左右，吧友@cghvbnv22 在windows吧转载“vista吧被覆灭”的贴子。但是其中用了前缀【大新闻】。由于该贴子后来似乎被windows吧吧务删了，故无图无地址。
不过随后AS在windows7吧发表的贴子和该贴子前缀雷同。http://tieba.baidu.com/p/4765000884】
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4765594907/8be72e550923dd54bdcd9bc0d909b3de9e8248d5.jpg)
***
【还是同一天 14:37，一吧友将导火索转载http://tieba.baidu.com/p/4765004586】
