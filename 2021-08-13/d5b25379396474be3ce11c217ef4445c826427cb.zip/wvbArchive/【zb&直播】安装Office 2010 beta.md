一楼喂（sha）熊[怒]
md刚刚发的帖子就即刻吞了[怒][喷]还tm广告[喷]三楼@ 人
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/91b7ca4ad11373f005ffe308ac0f4bfbf9ed045e.jpg)
@VistaWithSP2 @happymax1212 @redapple0204 @zhukun200098 @放射星云7601
office 2010这个资源也是最近从某个吧友上收到的[滑稽]然而今天想试一试安装来看看是怎样的。实际上之前逛WBC吧的时候发现某个坟贴里面有一张图就是Longhorn安装了Office 2010 Beta[滑稽]不过可惜已经找不到了，然而只给出了启动画面，而且只有略缩图[喷]
现在正式直播[滑稽]
先发两张图先，这是我之前装svr2003 Beta的时候安装Office2010 Beta的截图[滑稽]
其实这里最搞笑的是当安装发生错误的时候会重复显示一句话2333333，[滑稽]然而这个错误实际上是系统还原被关闭的锅[滑稽]（这也是某吧友解释的）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/17d876dea9ec8a13a2c3d977ff03918fa2ecc046.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/c27fc11fa8d3fd1f0bc82cad384e251f97ca5f5d.jpg)
好了，现在先启动一下虚拟机[滑稽]顺便猜猜这是什么系统[滑稽]（不准看下面的图）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/94de4f35349b033bb0ff754d1dce36d3d439bd2c.jpg)
另外这虚拟机经常意外关闭，所以呢有时会这样[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/f47beb5594eef01f11a19152e8fe9925be317de1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/20ad422cd42a2834ddd1bf9c53b5c9ea14cebf2c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/112ee6ca39dbb6fd23ee6cb10124ab18952b37e1.jpg)
***
先装了Tools先，不然很容易卡死[喷]话说这Core2跑虚拟机还真是不行，卡死了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/d01b11c7a7efce1bbeb4415da751f3deb68f65fb.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/2dd6284b20a44623d8072cf59022720e0ef3d74a.jpg)
另外说一下一些安装的要求，除了硬件配置以外，还需要一些东东：
1、Windows Installer 是3.5以上
2、要装Net Framework 3.5
3、NT5.x的系统必须要SP2以上（貌似是这样），NT6.x的系统好像没有这方面的限制
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/e4361a1fd21b0ef4739113c9d5c451da80cb3e25.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/f08aad8165380cd76f912a7aa944ad345b828194.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/d01b11c7a7efce1bbf27405da751f3deb58f650a.jpg)
安装超久，看来以后打死不用VMWare[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/dc76b659ccbf6c81bf50a47fb43eb13532fa4033.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/94cbe095a4c27d1eb540b35313d5ad6edcc4383c.jpg)
不过到了这里翻车了[喷]给回滚回去了，未知的安装错误[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/3b7df9500fb30f2438ed6694c095d143ac4b0323.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/b828b601baa1cd112a86f8b7b112c8fcc2ce2d6e.jpg)
然后我由试过了在HomeServer以及正式版的XP上都是没用[喷]看来还真是说中了，不仅系统有炸弹，这个也有炸弹[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/1b41aeeb15ce36d33f7377a732f33a87e850b12c.jpg)
然后还有一点就是可能NT5.x的Server系统需要MSXML6.0以上
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/42fc1cf50ad162d944db968b19dfa9ec8b13cd62.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/8808a4cfc3fdfc03cf23172fdc3f8794a6c226c7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/edbfb61273f08202da8c65a843fbfbedaa641b04.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/dde29afbaf51f3de96c84df39ceef01f3b297920.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/f86dce004c086e06ade7cbdc0a087bf408d1cbd4.jpg)
看来等下要换一个姿势来安装，先把Office2010Beta的时间炸弹破了先[滑稽]（估计就是这个惹得锅）[喷]显示未知错误
试了N次，终于安装成功了[滑稽][心碎] 我把物理机的时间调成了09/7/9之后安装成功
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/b2ebd9086b63f624a997db948f44ebf8184ca351.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/4c23f62297dda1444a848e25bab7d0a20ef4868a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/c760c3c37d1ed21b4033cc72a56eddc453da3fa0.jpg)
不得不说，这启动动画比正式版的好看很多，黄绿结合的[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/49d0cc19972bd4076ecf3e6a73899e510eb30916.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/7625482fb9389b50b1be0dc58d35e5dde5116ede.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/8a7402390cd79123744d78e3a5345982b0b780ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/222d95d2572c11df088b53b46b2762d0f503c2c1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/cb20d41d8701a18b0af3fed8962f07082938fe07.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/7d9932fab2fb4316dd0596ed28a4462308f7d301.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/f20f24176d224f4a92c39f8401f790529a22d1c1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/e6eacfd2fd1f4134ba58e9e92d1f95cad0c85e2b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/891e72cf36d3d539658ee3543287e950372ab0e8.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/90e26e25ab18972b8d6fec5deecd7b899c510ac1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/91fdd4df9c82d158ed30b526880a19d8be3e42e8.jpg)
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/99c7af94d143ad4bb485aa578a025aafa60f06f7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/b7f7f68ea0ec08faf93efc3051ee3d6d54fbda65.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/dedb600928381f307b27623ea1014c086f06f065.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/191a5a6c55fbb2fbed18b785474a20a44723dc68.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/dea568b20f2442a7b9231232d943ad4bd0130269.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/dba428c3d56285351ade3db698ef76c6a6ef6365.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/e9835e13b31bb0517a165cbf3e7adab44bede069.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/f7b124a88226cffc67d45325b1014a90f403eaa5.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/fccad63433fa828b8fdd7174f51f4134950a5aa4.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/6e29c4cd7cd98d10f3ede3a6293fb80e7aec9066.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4782230837/cb20d41d8701a18b0bd3fdd8962f07082938fe67.jpg)
资源楼：
Office 2010 Beta：![](http://pan.baidu.com/s/1geRb3z1
安装图集：![](http://pan.baidu.com/s/1kVyevPH
[滑稽]
另外还忘了说一下，貌似这个office 2010 beta是无法激活的，即使打开后弹出密钥过期的对话框，但是点了还是没反应，不能激活（就是点change key这个按钮都是没反应的）[喷][滑稽]
下面说明一下安装的条件（office 2010 beta安装起来的确有些麻烦）：
1、破解时间炸弹（将虚拟机的时间调成09/7/9）
2、打开系统还原
如果是nt5.x系统的话，建议按照以下条件：
1、安装net framework 3.5
2、windows installer 3.5以上，建议4.0
3、部分server系统可能需要MSXML，请安装MSXML 6.0
