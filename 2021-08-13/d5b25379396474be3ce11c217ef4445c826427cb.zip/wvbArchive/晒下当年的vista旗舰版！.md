ms正版软件镇楼 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4883168241/d2b1b189d43f8794b035703ddb1b0ef419d53acb.jpg)
喜闻乐见的vista旗舰版，闪闪发光的光盘[滑稽] 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4883168241/d2acb608b3de9c823bfec29c6581800a18d8437b.jpg)
