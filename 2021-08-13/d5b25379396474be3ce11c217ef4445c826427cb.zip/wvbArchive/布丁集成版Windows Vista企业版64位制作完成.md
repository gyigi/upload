采用dism++制作，集成补丁至2016.12，集成IE9、DirectX11
优化：
1.桌面默认存在计算机图标
2.默认显示文件扩展名
3.explorer在不同进程中打开
4.（经典及最小化时）显示完整文件夹路径
5.不参加客户体验报告计划
其它无任何改动
正在上传，先放几张图
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4932226222/5fc48e25b899a901a567eb6014950a7b0308f508.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4932226222/f9ccfc514fc2d562d7b060bbee1190ef77c66c25.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4932226222/68cc7831e924b899416ec96e67061d950b7bf608.jpg)
***
install.wim大小3.92GB，iso镜像总大小为4.26GB（4.7GB的DVD还是刻得下的[滑稽]）
上传ing，待会儿再往mega里也尝试丢一份[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4932226222/8eeffa17fdfaaf51aace3ce9855494eef11f7aa8.jpg)
@longhorn4093 以后可以用这个做母盘
@ss433_2 @af的5apu @redapple0204 @焊锡补牙
[滑稽]https://me[滑稽]ga.n[滑稽]z/#!S5kzBbZS!eruxCjhH_8FJxlliOmYWz9RFa9lEiaA_BV4s8kmcwwc
接下来是度盘[滑稽]
p[滑稽]an.b[滑稽]aidu.co[滑稽]m/s/1pLATGwV
@longhorn4093 @ss433_2 @af的5apu @redapple0204 @焊锡补牙 发布啦[哈哈]
