熟悉Vista的朋友都知道，微软在2017年4月11日结束了对Vista的支持，意味着Vista不会再得到任何更新[泪]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/43cf3cb4c9ea15cef5d83015bc003af33b87b2ea.jpg)
这是不是意味着Vista的生命走向终结了呢？答案是否定的，熟悉Vista的朋友肯定知道Vista的姊妹，也就是和Vista同样是NT6.0内核的Server 2008依然健在，它的生命周期直到2020年1月14日才会终止，所以我们可以把Server 2008的更新拿来给Vista用，理论上大部分更新是通用的，达到给Vista延长生命的目的。[吐舌]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/2dd6284b20a44623ae29747e9222720e0ef3d7c5.jpg)
我将一直测试以后每月发布的Server 2008的更新是否适用于Vista，并将适用于Vista的更新放在这个帖子提供给大家[太开心]
西雅图时间2017年5月9日上午10点，也就是北京时间凌晨1点，微软向所有受支持的系统推送了5月月度更新。由于Vista已经于上个月结束支持，所以被微软排除在更新之列。Server 2008收到了这次月度更新，共有12枚更新：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/8861b642ad4bd1132170692e50afa40f4afb0566.jpg)
***
经过本人的测试，除了Windows 恶意软件删除工具-2017年5月（KB890830）无法安装在Vista上面外，其它的11枚更新（KB4015193、KB4018271、KB4018466、KB4018556、KB4018821、KB4018885、KB4018927、KB4019115、KB4019149、KB4019204、KB4019206）均可以成功在Vista上安装。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/dedb600928381f3096a453b5a3014c086f06f067.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/66633eef3d6d55fb287ba83a67224f4a21a4dd67.jpg)
***
而Windows 恶意软件删除工具-2017年5月（KB890830）在Vista上安装会提示不支持该操作系统，然后不能安装
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/20ad422cd42a28348c05e81751b5c9ea14cebf05.jpg)
稍后我将在本楼回复中提供这11个更新打包的网盘分享[太开心]
6月更新日到了，微软这次很给力，给不受支持的旧系统也提供了更新，根据微软官方博客的说法，此次给不受支持的旧系统提供更新是为了保护用户免受潜在的国家级别网络攻击活动的威胁（protect against potential nation-state activity）,此次微软给不受支持的Windows XP, Windows Vista, Windows 8, Windows Server 2003和Windows Server 2003 R2都提供了更新，原文截图：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/06d76ef6905298227dbe7383ddca7bcb0846d4d2.jpg)
***
原文链接：https://blogs.technet.microsoft.com/msrc/2017/06/13/june-2017-security-update-release/
原文大意：微软针对旧版本操作系统发布特别的安全更新，保护用户免受潜在的国家级别安全隐患活动的威胁
在本周微软例行的“周二安全更新日”，我们已采取了相应措施提供特别的重要安全更新，解决风险较高的漏洞问题，防止黑客利用这些漏洞制造国家级别网络攻击的活动或泄漏信息。在本周发布的所有安全更新中，有些是全新开发的，有些则是面向旧版本操作系统的（根据后续特别支持协议相关规定），用户从即日起就可以进行下载和安装。开启了自动更新功能的用户无需进行任何操作便可受到保护。对于需手动操作更新或旧版操作系统的用户，我们鼓励他们尽快应用这些更新。
我们的安全团队严密监控不断涌现的各种威胁，据此来排定优先级别，安排相关工作，并及时采取相应措施。我们致力于确保用户免受这些潜在威胁的攻击，同时我们也善意提醒仍使用旧版本操作系统（如Windows XP等）的用户尽早前往“微软下载中心”（Download Center）或”更新目录“（Update Catalog）优先下载和安装这些重要的安全更新。
运行仍然处于正常服务支持的操作系统（如 Windows 10 和 Windows 8.1 等）并启动了自动更新功能的用户无需进行任何操作，便可受到保护，系统会自动下载和安装这些安全更新。（Via：微软中国）
Eric Doerr
微软安全响应中心总经理 Eric Doerr
***
更多信息：
***
详细更新列表请点击微软安全公告 4025685 进行查阅
使用 Windows Server 2008、Windows 7、Windows Server 2008 R2、Windows Server 2012、Windows 8.1、Windows 8.1 RT、Windows Server 2012 R2、 Windows 10、以及 Windows Server 2016 的用户请点击 Microsoft Knowledge Base Article 4025686 获取帮助
使用 Windows XP、Windows Vista、Windows 8、Windows Server 2003、以及 Windows Server 2003 R2 的用户请点击 Microsoft Knowledge Base article 4025687 获取帮助
使用 Windows Embedded 版本的用户请点击 Microsoft Knowledge Base article 4025688 获取帮助
若不清楚您使用的是哪个版本 Windows 产品，请点击此处查询
更多疑问请点击常见问题
***
下面我们说说Vista，微软给不受造成的旧系统保护用户免受潜在的国家级别网络攻击活动的威胁（protect against potential nation-state activity）写了一份《Microsoft 安全公告 4025685： 旧平台指南： 2017，6 月 13》链接https://support.microsoft.com/zh-cn/help/4025687/microsoft-security-advisory-4025685-guidance-for-older-platforms，上面列了三个表格
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/f47beb5594eef01f5c865285eafe9925be317dd1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/f9ccfc514fc2d562d2aa9aaded1190ef74c66cc1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/792fd1fc5266d016a78bd4689d2bd40737fa35d1.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5109818522/bcf7f544d688d43f270bdbb2771ed21b0cf43bc1.jpg)
***
其中表格1中列举的MS08-067、MS09-050、MS10-061、MS14-068、MS17-010是今年4月之前的安全公告，对Vista影响的漏洞已经修复了，MS17-013漏洞不影响Vista。而表2、3上的安全公告有5个影响Vista，微软把修复这5个安全公告的漏洞的更新于6月更新日提供给Vista，此次6月更新日Vista收到的更新为KB4018271、KB4018466、KB4019204、KB4021903、KB4024402这五枚更新，而KB4018271、KB4018466、KB4019204这三枚更新早在5月就已经推送给了Server 2008，所以去掉这三枚更新后再和Server 2008收到的6月更新作比较，那就剩下两枚了：KB4021903、KB4024402。而此次Server 2008收到的6月更新共有KB890830、KB4021558、KB4021903、KB4021923、KB4022008、KB4022010、KB4022013、KB4022883、KB4022884、KB4022887、KB4024402这十一枚，除掉KB4021903、KB4024402这两枚已经推送给Vista的，再除掉KB890830(这个是Windows恶意软件删除工具)，Server 2008独占的6月更新还有KB4021558、KB4021923、KB4022008、KB4022010、KB4022013、KB4022883、KB4022884、KB4022887这八枚，所以微软推送给Vista的六月更新依然是不完整的，缺了KB4021558、KB4021923、KB4022008、KB4022010、KB4022013、KB4022883、KB4022884、KB4022887这八枚，因为微软博客说此次对不支持的旧系统提供更新的目的是为了保护用户免受潜在的国家级别网络攻击活动的威胁（protect against potential nation-state activity），所以估计是因为这八枚更新所修复的漏洞的影响达不到国家这个级别所以微软没给对不受支持的Vista提供，所以Vista依然需要安装Server 2008独占的八枚6月更新来延长生命
@xkai 这是吧友@wq8245 总结的更新替换信息，感谢[大拇指] 替换KB4018271是IE9的5月累积安全更新(微软6月推送给Vista的更新)，直接用6月累积安全更新KB4021558(Server 2008独占的八枚六月更新中)
六月更新替换先前补丁 :
KB4021903 替换 KB3080446 
KB4022008 替换 KB2839894
KB4022013 替换 KB4011981
KB4022883 替换 KB3203859
KB4022887 替换 KB4012497
西雅图时间2017年7月11日上午10点，也就是北京时间凌晨1点，微软向所有受支持的系统推送了7月月度更新。Server 2008收到了这次月度更新，共有16枚更新，经过本人的测试，除了Windows 恶意软件删除工具-2017年7月（KB890830）无法安装在Vista上面外，其它的15枚更新（KB4022746、KB4022748、KB4022914、KB4025240、KB4025252、KB4025397、KB4025398、KB4025409、KB4025497、KB4025674、KB4025872、KB4025877、KB4026059、KB4026061、KB4032955）均可以成功在Vista上安装。待会儿分享打包[吐舌]
