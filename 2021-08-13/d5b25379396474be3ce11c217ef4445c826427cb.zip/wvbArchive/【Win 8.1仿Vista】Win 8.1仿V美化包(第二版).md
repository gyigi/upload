链接:https://pan.baidu.com/s/1eR6rSsU 密码:j74u
Win 8.1仿V美化包(第二版)文件说明：
***
系统替换类
大部分可能只适用Windows 8.1 Update 1
系统修改类
WinFlip(实现Win7切换特效)【默认英文，可以设置中文，Windows XP/8.x/10可用】
hy_7880D2S3.exe(火萤动态桌面2.0)【中文，Windows 2000/XP/2003/Vista/7/8.x/10可用】
OldNewExplorer 1.1.8.2(还原win7样式)【英文，Windows 8.x/10可用】
开始菜单
ClassicShellSetup_4_3_0-zhCN (Classic Shell)【中文，几乎所有Windows可用】
VISTA ICONS【如果图标已经是Vista的样子，这个没有用了】
Windows VISTA皮肤【诺瓦露改进的皮肤，Windows 7/8.x/10可用】
系统组件类
边栏【中文，Windows Vista/7/8.x/10可用】
Windows 7 小游戏【多语言(含中文)，Windows 8.x/10可用】
WinSAT(Windows 8.0系统评分)【中文，Windows 8.1/10可用】
wlsetup-all (Windows 软件包2012)【中文，Windows 7/8.x/10可用】
WMC (Windows 7媒体中心)【中文，Windows 8.1/10可用】
墨球 XP TPC 显光标版【中文，Windows XP/2003/Vista/7/8.x/10可用】
微软拼音新体验2012【中文，Windows 8.1/10(10240～14393)可用】
 主题类
AeroGlassGUI (Windows 8加入阳光效果)【英文，Windows 8.x/10可用】
Aero Glass For Win8.1去弹窗去水印1.2【英文，只适用Windows 8.1 Update 1】
Aero Glass For Win8.1 1.4【英文，只适用Windows 8.1 Update 3】
Aero Glass For Win8.1 1.3与GlassPwn v2.0.1【适用范围未知】
屏保
MarineAquarium 3.3.6041.0(热带鱼屏保)【中文，几乎所有Windows可用】
theme864 (怀旧屏保与主题)【中文，Windows 8.x/10可用(仅64位)】
Win98怀旧屏保系列【Windows 8.x/10可用】
破解主题补丁
UltraUXThemePatcher_3.1.4【Windows 7/8.x可用】
软媒美化大师(里面有破解主题功能，但要小心)【中文，WindowsVista/7/8.x/10可用】
主题
Vista VS Clear【只适用Windows 8.1 Update】
Win8 RP for Win8.1.1【只适用Windows 8.1 Update】
其他
8ootLogoChanger 1.2.09(Windows 8修改开机画面程序)【英文，Windows8.x可用】
CustomizerGod 1.7.6.1(自定义系统外观) 【英文，Windows Vista/7/8.x/10可用】
HEU KMS Activator V11.2.0(HEU KMS激活) 【中文，Windows 7/8.x/10可用】
Remove Shortcut Icon 1.0(Win8去箭头、盾牌) 【中文，Windows8.x/10可用】
ResourceHacker.4.2.5.146.chs.th_sjy(资源编译器) 【中文，几乎所有Windows可用】
移除开始按钮 for Windows 8.1 【英文，仅适用Windows 8.1】
移除显示桌面按钮【英文，Windows 7/8.x/10可用】
