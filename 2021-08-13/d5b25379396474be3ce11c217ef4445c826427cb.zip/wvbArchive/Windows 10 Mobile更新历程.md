看到吧里不少人都开更新帖，我也来开一个[哈哈]
我们先来看一下Windows 10 Mobile目前的最新版本--Redstone 2（红石2）快速预览版Build 15055，又称Creators Update（创意者更新），Version 1703（版本1703）
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/2c75e70b19d8bc3eb789cb3d8b8ba61eaad345bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f9f52d91f603738df6ccc1d5ba1bb051fa19ecbd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/92ef69f51bd5ad6ef261a91d88cb39dbb4fd3ca6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/c0fe7ed9bc3eb13534467a4caf1ea8d3ff1f44bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/592cdb3fb13533fa8a375ed9a1d3fd1f43345bbd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/fccad63433fa828bafa25014f41f4134950a5abd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f1c154fb828ba61ea26f05d84834970a324e59bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/730ee58aa61ea8d3f6a3b9f39e0a304e271f58bd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/c27fc11fa8d3fd1f4d886fcd394e251f97ca5fbd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/e6eacfd2fd1f41349ab6c8892c1f95cad3c85ebd.jpg)
当地时间2015年1月21日早上9点，即北京时间1月22日凌晨1点，微软召开了名为“The Next Chapter”（下一篇章）的发布会：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/833aa4fcfc039245c9f92bf88e94a4c27f1e25ea.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/e3381bd88d1001e9f482def8b10e7bec56e79785.jpg)
会上微软介绍了Windows 10 for phones（后来正式名称定位Windows 10 Mobile）的诸多激动人心的特性，并宣布第一个预览版将在2月推送：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/035de527cffc1e17d9f346c64390f603718de9eb.jpg)
***
以下是微软“The Next Chapter”（下一篇章）的发布会上介绍的Windows 10 Mobile的特性：
1.全新的开始屏幕
微软的Win10手机系统采取整张背景图片设计，在色彩上更加鲜艳。动态磁贴保留了WP8.1上的大部分功能。至于动态磁贴是否可以调节透明度和自定义背景，现在还不清楚。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/d2b1b189d43f8794bd2775d6db1b0ef419d53a66.jpg)
2.全新应用列表
左滑开始屏幕出现应用列表新增排序功能，并加入Win8的最近使用或者按时间排序等功能。可以看到这个页面还不可用自定义背景图片。
增强型的通知中心+快速操作
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/99c7af94d143ad4be4f67b388b025aafa60f0666.jpg)
3.增强型的通知中心+快速操作
Win10手机系统的通知中心与Win10电脑版可以无缝链接，并且快速操作也可以折叠或者加入更多选项。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/a9a4522bc65c1038f9a6f33abb119313b27e8967.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f9f52d91f603738de69231daba1bb051fa19ec67.jpg)
4.全新的系统设置
更新后的Win10手机系统，设置分类更加简洁，可分为折叠和分组管理，一目了然。具体细节选项有待关注。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/b227302d11dfa9ecf8f66bef6bd0f703938fc167.jpg)
5.可交互通知操作
短信来了，可以直接在状态栏接通或者回复，快速便捷，微软胜过安卓和iOS。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/09a06e22dd54564e7e92d9c1bade9c82d3584f4c.jpg)
未完待续
***
接上面：
6.可缩放的移动键盘和语音输入法
微软在Win10 for Phone系统中进一步更新了输入法，其中可缩放键盘可以解决单手输入问题，语音也可以快速补全要说的话。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/91f4dda0cd11728b48dbb1dac1fcc3cec1fd2c4c.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/4fd025a6d933c895e288a583d81373f08002004c.jpg)
7.短信集成Skype等通讯应用
在WP7时代，微软的短信和MSN是融合在一起，但是WP8之后微软将此功能砍掉甚是可惜。现在全新的Win10 for Phone补全了这些。用户可以自由选择。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/b8ede119367adab41d2626bb82d4b31c8501e44d.jpg)
8.Win10手机全新的Office发布
期盼已久的Win10手机版Office终于要准备好面世了，与Win10电脑版Office进行无缝链接。通用应用也带来史上最强大的Office移动版。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/d17bc7ed08fa513d5c5c5126346d55fbb0fbd94d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/3b006dd062d9f2d338ca1917a0ec8a136127cc60.jpg)
9.全新的Outlook邮箱应用
新的Win10手机版Outlook更加美观，处理邮件更具效率，体验上升。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/3b1833e636d12f2e72f3939846c2d5628735684d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/745c39de8db1cb13a19f01ebd454564e90584b4d.jpg)
10.全新的Win10电脑、手机相册
统一的Win10相册应用增加自动分类、收藏、无缝同步，还可以自动美化照片。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/a529801090ef76c67309c6d39416fdfaad516760.jpg)
未完待续
***
11.全新的人脉
人脉界面更加清新，整洁干净，个人信息清晰明了
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f7b124a88226cffc5f949a4ab0014a90f403ea85.jpg)
12.全新的Xbox Music
微软已经发布最新的Win10系统Xbox Music应用，界面统一，美观度上升。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/0b0f9cecab64034f463cfffea6c3793108551d4d.jpg)
13.全新的地图
Win10电脑、手机界面统一，同步收藏，互相联动。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/035de527cffc1e17c801a9c94390f603718de985.jpg)
14.全新的斯巴达浏览器也有Win10手机版
斯巴达浏览器书签、手势操作、集成Cortana，更多信息一键搜索
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/b227302d11dfa9ecf8df6bef6bd0f703938fc14e.jpg)
本节完[滑稽]今天就先更新这么多，慢更[滑稽][滑稽][滑稽]下节预告：微软在2015年2月推送的Windows 10 Mobile首个预览版的更新内容[滑稽]欢迎催更[滑稽][滑稽][滑稽]
本层为目录，各版本所在楼层请看本层恢复
Threshold 1
Threshold 2
Redstone 1 
Redstone 2
Redstone 3
未完待续
***
[滑稽]此楼留给Redstone 3以后的版本
开更，正如微软在”The Next Chapter”（下一篇章）发布会上宣布的那样，微软如约在2015年2月推送了Windows 10 Mobile第一个预览版，遗憾的是首个预览版只支持6部手机：
分支：Threshold 1
版本号：Build 9941.12498
阶段：Technical Preview
推送通道：Insider Fast
推送时间：北京时间2015年2月13日凌晨
支持的手机：Lumia630、Lumia635、Lumia636、Lumia638、Lumia730、Lumia830
北京时间2015年2月13日凌晨，微软正式开启Win10手机预览版更新推送计划，推送首个预览版Build 9941.12498，首批机型已经公布，没有国行机型，没有高端机型，包括Lumia630、Lumia635、Lumia636、Lumia638、Lumia730、Lumia830。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/c5c182dce71190ef6bd81927c71b9d16fcfa6018.jpg)
具体的注意事项：
不要说我们没有警告过你…
Technical Preview适用于Windows Phone爱好者和技术专家。如果你认为S/MIME具有打破常规的潜力，你可能希望暂时坚持使用Windows Phone 8.1。
请按照以下步骤下载Technical Preview：
1.注册加入Windows会员计划（如果尚未注册）。
2.查明Technical Preview是否适合你，并确保你的手机在受支持的手机列表中。预发行软件不会始终如期运行，并且可能导致你的手机永久停止工作。
3.从手机上打开此网页，然后单击“下载Windows会员应用”。你还可以通过手机在应用商店中搜索Windows会员应用。
4.在它完成下载后，在你的手机应用上打开Windows会员应用并按照说明安装Technical Preview。
如果微软没有推送，说明并没有准备好，对手机损害也较大。由于Windows10手机系统不同于以往，谨慎一些也是好事。
Build 9941.12498更新内容：
微软官方博客已经公布，Win10手机预览版首个Build版本更新内容概要：
• 开始屏幕自定义背景（这个功能WP8.1就有了，可惜这个Build还没有随意调磁贴透明度的功能）
• 应用群组分类，比如最近新增
• 通知+操作中心的扩展快速操作
• 交互性通知，可以直接文本回复
• 文本语音转换输入，是全局UI
• 中文输入法，全键盘拼音支持滑动输入，自动云联想
• 关机日历事件提醒
• 新的Office应用，是Windows通用应用，可以跨设备工作
• 新的Word应用展示手机版Ribbon UI
• 新的PowerPoint应用展示动画演示
• 新的Outlook和日历应用
• 新的斯巴达浏览器
• 新的相册应用，自动美化、自动创建相册及其他分类
• 新的Xbox音乐、视频和地图应用
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/2b9791256b600c335f702930134c510fd8f9a137.jpg)
***
外媒发现的Build 9941.12498的四项隐藏技能：
1.Windows10手机预览版终于对操作中心进行了扩展，现在用户可在操作中心添加更多快速操作图标。但如果你长按任意快速操作图标，就将直接进入该图标所在设置选项。如上图所示，如果长按操作中心中的“亮度”图标就会直接进入“亮度”设置
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/2b946b328744ebf8c22e95c7d0f9d72a6259a7e5.jpg)
2.如果你在Win10手机中复制了一段文字接着锁屏的话，复制的文字仍不会丢失。这就是说，Win10手机用户在解锁手机后仍可找到熄屏前复制的文字并进行粘贴操作。
由此我们可以看出微软在细节方面的努力，而微软最后定会带来一个友好完善的Win10手机版系统。
3.移动手机键盘：在任何屏幕尺寸大于5英寸的Win10手机中，用户都可长按键盘空格键的方式拖动键盘到屏幕任意位置。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/edbfb61273f08202268d60c742fbfbedaa641b24.jpg)
4.可操作通知“点赞”功能：当Win10手机收到一条通知消息或当用户浏览操作中心时，不仅可以通过扩展通知的方式浏览及回复消息，还能直接为社交应用（如Facebook）中的好友状态“点赞”。
第二项“点赞”功能或许还不支持国内的社交应用，不过我们也由此看出微软在细节方面的努力，而微软最后定会带来一个友好完善的Windows10手机版系统。
微软解释为啥首个预览版Build 9941.12498不支持高端机型：
微软在2015年2月13日凌晨为Lumia830，Lumia730等机型开启了更新Win10预览版的权限，令人意外的是，首批名单中我们并没有看到Lumia930，Lumia1520，Lumia1020等高端Lumia手机的名字。
就此问题，微软Windows10负责人Aul在推特中进行了解释。
在开始推送Win10手机预览版之后，Aul表示：
“大部分Lumia手机，无论是最高端的设备，还是最实惠的设备，都可以更新到Win10手机版。也就是说，在目前最初的Win10手机预览版，我们通过向这一小部分机型推送固件，来保证我们的系统分区没有问题，这也能帮助我们修复固件，使其变得更加稳定。此次固件也是我们首次公开测试固件，之前我们只在微软内部进行测试。在过去的4-6个月内，我们先将精力放在了一个特定的设备之上，然后我们才开始测试其它型号设备。”
之后，Aul又解释了为何名单上没有高端设备的问题：
我们很快将发布一个名为“分区合并”的功能，这能帮助我们通过调整空间来使手机有更多的空间更新系统。在此功能来临之前，我们需要运营商来为设备配置足够大小的分区空间进行升级，众所周知，高端设备往往严格的分区控制。但是请注意，这并不代表Win10手机会比WP8.1占有更多的磁盘空间，一旦“分区合并”完成，将会有更多的设备加入名单之中。
我们期待微软能尽快完成“分区合并”功能，同时希望我们的运营商也可以在第一时间与微软配合，让Lumia930、Lumia1520等高端设备用户也能尽早体验到Win10手机预览版。
Build 9941.12498的IE已支持”视频直播”功能
微软之前已确认称Windows 10 Phone首个版本（Build 9941.12498）中的IE浏览器使用了最新的渲染引擎，将供即将到来的斯巴达浏览器使用。这个全新引擎不仅在HTML5基准测试中强于Windows 10 Phone中IE浏览器的表现，还增加了一项“隐藏技能”。今天已有眼尖的用户发现了Windows 10 Phone中IE浏览器的新变化。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/2b946b328744ebf8cf4d96c7d0f9d72a6159a704.jpg)
从上方截图大家可以猜到，Windows 10 Phone版IE浏览器现已支持“视频直播”功能。如果你的手机运行了Windows 10 Phone系统，那不妨在IE中打开视频网站中的视频直播页面试试看。而在运行Lumia Denim及WP8.1 GDR1设备的IE中打开类似页面则会显示“不支持该系统“提示。
下次Windows 10 手机预览版更新将支持全系WP8.1 Build版本！
首个 Windows 10 手机技术预览版本(Build 9941.12498)并不支持版本号高于 8.10.12419.341 的 WP8.1 设备升级。目前市场中有两种高于上述版本号的 WP8.1 Build 版本：8.10.14226.359与8.10.14234.375。因此搭载这两种系统版本的设备即便属于 Windows 10 Phone 首次更新支持机型，也需要通过《Windows Phone 恢复工具》降级后才可升级 Windows 10 手机预览版。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/8861b642ad4bd11306774bca53afa40f49fb0581.jpg)
但下次 Windows 10 手机技术预览版更新将兼容全系 WP8.1 Build 版本，这一消息已得到 Insider 项目负责人 Gabriel Aul 的证实：“是的，下个 Build 版本将支持更高(WP8.1)版本升级。”
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/ab30d04443a98226489fd7df8382b9014890ebe6.jpg)
现在有了微软官方的保证，大家尽可待 Windows 10手机预览版下次更新到来时放心升级了！
第一个预览版Build 9941.12498已更新完，下面更新第二个预览版Build 10051的内容[太开心]
第二个预览版Build 10051
分支：Threshold 1
版本号：Build 10051
阶段：Technical Preview
推送通道：Insider Fast
推送时间：北京时间2015年4月11日凌晨
支持的手机：Lumia 1020
Lumia 1320
Lumia 1520
Lumia 520
Lumia 525
Lumia 526
Lumia 530
Lumia 530 Dual Sim
Lumia 535
Lumia 620
Lumia 625
Lumia 630
Lumia 630 Dual Sim
Lumia 635
Lumia 636
Lumia 638
Lumia 720
Lumia 730
Lumia 730 Dual SIM
Lumia 735
Lumia 810
Lumia 820
Lumia 822
Lumia 830
lumia 920
Lumia 925
Lumia 928
Microsoft Lumia 430
Microsoft Lumia 435
Microsoft Lumia 435 Dual SIM
Microsoft Lumia 435 Dual SIM DTV
Microsoft Lumia 532
Microsoft Lumia 532 Dual SIM
Microsoft Lumia 640 Dual SIM
Microsoft Lumia 535 Dual SIM
（以上型号包括国行Lumia在内）
不支持机型：
Icon、930、640XL
本次更新版本号为Build 10051，下载包大约在450MB，WP8.1GDR1系统可以直接升级Build 10051，国行Lumia在列。
下面是Windows10手机预览版10051具体的重要更新内容：
1.斯巴达浏览器：本次加入斯巴达浏览器早期版本，是Modern移动应用，新的引擎，新的应用包括早期的阅读模式和阅读列表，斯巴达浏览器还不是默认的，并且与IE11共存。
2.全新的邮件和日历应用：Outlook Mail和Outlook Calendar取代之前的邮件、日历，都是Windows10通用应用。这些应用带来全新的UI设计，邮件和日历之间可以平滑切换，无需返回到开始屏幕。邮件自带手势功能，可以滑动删除、移动、标记、未标记。
3.全新的电话和短消息应用：电话和短信应用得以更新，带来全新的界面设计，比如新的app bar。
4.全新的人脉应用：全新的通用人脉应用，带来持续的服务，可以接入Exchange、Outlook.com、Gmail、Facebook等等。轻松管理联系人。
5.全新的地图应用：这次是新的通用地图应用首次出现，带来探索和导航功能，最好的地图、航空影像、丰富的搜索数据、语音导航，由必应地图和Here地图提供支持，融合到一个应用中。
6.升级版的后台多任务切换：长按后退键，可以出现全新的后台任务卡片，包括最近的使用应用。比如在Lumia1520中可以看到全新的网格状后台界面，最近使用应用数量提高到15个。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/a529801090ef76c6aa5e01d39416fdfaad5167ab.jpg)
***
Win10手机系统预览版Build 10051已知问题大全
已知问题如下：
1、OneDrive自动备份照片功能也许会失效，也就是用户所拍摄照片有可能不被自动上传，如果你打算回滚WP8.1，一定记得先做好备份，以免丢失重要照片。
2、Office Hub被暂时移除，也就是用户无法使用最新版Win10手机系统进行办公，包括Word、Excel、PowerPoint以及OneNote文件都将无法正常打开。通用版Office预览版应用将在几周内上线。
3、如果你是蓝牙耳机用户那么你需要注意了，一切经由蓝牙传输而与Cortana小娜产生的互动都将失效，也就是你无法使用蓝牙耳机为小娜发送命令，失效功能包括阅读送达短信、搜索、调戏以及所有系统控制功能（例如音乐播放、打电话与打开应用等）。
4、升级至Win10手机系统预览版后，一些安装在SD卡中的应用也许会失效，可以通过卸载重装的方法进行修复。
5、有1%的几率会发生来电无铃声的情况，如果碰巧这1%的几率发生在某个重要来电时，就会发生一系列悲剧。
6、消息屏蔽+拦截失效，也就是你无法屏蔽骚扰电话或是你前男友的短信。
7、如果你从Win10手机预览版第一版Build 9941升级至最新版Build 10051，会发生MMS设置丢失问题，全新的消息应用暂时无法手动载入此类设置，如果MMS对你很重要，慎重更新。如果你已经更新最新版Win10手机版，则需要使用Windows Phone Recovery Tool来回滚至WP8.1。
8、如果你从Win10手机预览版第一版Build 9941升级至最新版Build 10051，开始屏幕中的相机与照片两个磁贴也许会丢失或出现问题，此时需要将其取消固定然后重新进行固定操作。
9、在一些512MB内存的经济实用型设备中，会发生应用随机崩溃的问题，而原因是目前内存管理机制尚未完善。
10、飞行模式无法开启。
11、走2G/3G/4G流量的移动数据连接无法关闭，也就是你对流量无法进行有效控制。
12、更新之后，也许需要重新将电话应用固定到开始菜单。
13、Insider Hub现在属于系统组件，不过在某些型号设备中也许无法运行。
以上便是目前Win10手机系统预览版10051存在的已知问题，不过微软承诺将在后续版本中将这些问题全部修复，而且目前Win10毕竟出于技术预览版状态，如果你发现一些特殊问题，可以通过反馈应用直接将想法告知微软，并且不要期待Win10手机版可以像目前WP8.1一样能够满足你所有关于稳定性和易用性的要求。
由于预览版的不确定性以及不稳定性，我们不建议缺乏动手能力与心理承受能力的用户进行任何尝试，更不建议用户将Win10手机版当作日常系统进行使用，如果因为更新Win10预览版而导致设备无法满足日常需求，建议使用微软官方发布的Windows Phone Recovery Tool回滚至Windows Phone 8.1，待Win10手机版趋渐成熟之后再行尝试。
***
Win10手机系统预览版10051已修复问题大全
已修复问题如下：
1、键盘布局已基于用户反馈进行更新，全新的键盘将在首页展示句号、逗号以及emoji表情按钮。如果用户需要切换语言，可以长按&123键进行选择。另外，用户也可以自行将emoji表情按钮通过设置替换为语言切换按钮。
2、微软小娜Cortana的图标分辨率现在会正确缩放。
3、从邮件、Facebook或其它应用打开照片应用选择图片时，会导致照片应用随机崩溃，此问题现已修复。
4、微软智能手环现已能正常与Win10手机系统预览版进行同步。
5、照片应用在开启之前会自动使用系统主题色，然后才会展示本地图片与OneDrive图片。
以上便是微软所进行的修复，Win10任重而道远，微软能做的还有很多，并且我们相信微软正在尽其最大努力带给我们最佳体验。
然而由于预览版的不确定性以及不稳定性，我们不建议缺乏动手能力与心理承受能力的用户进行任何尝试，更不建议用户将Win10手机版当作日常系统进行使用，如果因为更新Win10预览版而导致设备无法满足日常需求，建议使用微软官方发布的Windows Phone Recovery Tool回滚至WP8.1，待Win10手机版趋渐成熟之后再行尝试。
本期更新到此结束，更新了第一预览版Build 9941.12498和第二预览版Build 10051的内容[滑稽]下期预告：Build 10052、Build 10080
第三个预览版Build 10052
分支：Threshold 1
版本号：Build 10052
阶段：Technical Preview
推送通道：Insider Fast
推送时间：北京时间2015年4月22日凌晨
支持的手机：与Build 10051相同（详见第29楼）
北京时间2015年4月22日凌晨，微软向Windows Insider“快速”会员推送了Win10手机预览版Build 10052更新，修复了Windows10 Build 10051中的诸多故障与Bug。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/9d3036db81cb39dbad9242b6d9160924a91830f0.jpg)
***
稍显遗憾的是这次更新并未包含任何新功能，但却修复了上次更新带来的大量不能忍的Bug。具体更新日志如下：
• 飞行模式已可正常启动；
• 数据流量开关已恢复正常；
• 在Build 9941更新后丢失的彩信设置现已恢复；
• 无法为其他语言下载键盘的Bug已修复；
• 某些设备（如Lumia1020）《相机》应用中的取景器显示故障现已修复。
此外，Lumia520用户现在已能再次下载Win10手机预览版更新，微软已完全修复之前的回滚变砖故障。
Windows 10 Phone Build 10052：第一印象 & 0x80070102错误和其他bug 
我们率先在 Lumia 525 和 Lumia 925 上安装了Build 10052，这是我们上手后的第一印象。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/03e20a234f4a20a4316f1d2799529822700ed0d6.jpg)
Build 10052 上手印象: 　　　　
相比 Build 10051 更加稳定，改进很多。　　
导航更流畅，甚至操作中心扩展也非常轻松。　　
Outlook 邮件崩溃错误(回复消息时) 也已解决。　　
Outlook 邮件和 Outlook 日历应用程序问题现在都已解决。
《Insider Hub》应用存在但还没有开放，可以卸载。　　
流量开关错误已解决，可从设置里打开和关闭移动数据。　　
《Lumia 专业拍摄5.5》速度更快(相比 Build 10051 的《Lumia 专业拍摄5.4》)。在 Lumia 525 和 Lumia 925 上，感觉《Lumia 专业拍摄》真的快了很多，相比之前差别很明显。取景器 bug 已解决。　　
斯巴达浏览器在性能上也改进了很多，滚动和移动大型网页时显得更轻快。
0x80070102错误:
Build 10052 仍存在没有解决的问题：没有安装相应的语言包，Cortana 无法执行指令。（PS:我们这里测试，英文语音包可以下载下来了，还得看人品（中文的还下载不下来），语言包下载下来后 Cortana 的一些基本功能也能用了；不过我们这是国内的 ip 所以 Cortana 一直是一句英文，一句中文。）
***
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/2dd6284b20a4462371bb84829122720e0ef3d7d6.jpg)
其他 Build 10052 bug：
在 Lumia 925 上，显示“不能截图”的消息，实际上截图已完成并可以在照片中看到。
这样度娘应该不吞帖了吧[喷]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/b8ede119367adab40c0437a382d4b31c8501e46b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/22249002918fa0ec6f1348ed2f9759ee3f6ddb6b.jpg)
***
Build 10052已更完，下面更Build 10080，从这版起Windows 10手机版的正式名称--Windows 10 Mobile就定了[滑稽][滑稽][滑稽]
第四个预览版Build 10080
分支：Threshold 1
版本号：Build 10080
阶段：Technical Preview
推送通道：Insider Fast
推送时间：北京时间2015年5月15日凌晨
支持的手机：全系列Lumia
Lumia 1020
Lumia 1320
Lumia 1520
Lumia 520
Lumia 525
Lumia 526
Lumia 530
Lumia 535
Lumia 620
Lumia 625
Lumia 630
Lumia 635
Lumia 636
Lumia 638
Lumia 720
Lumia 730
Lumia 735
Lumia 810
Lumia 820
Lumia 822
Lumia 830
Lumia 930
Lumia icon（929）
lumia 920
Lumia 925
Lumia 928
Lumia 430
Lumia 435
Lumia 532
Lumia 540
Lumia 640
Lumia 640 XL
***
HTC One M8
Xiaomi Mi4
北京时间5月14日微软Windows Insider项目负责人Gabe Aul在其推特上表示，目前Win10手机版10080进展很顺利，将会尽快向用户推送。他还表示，当前存在几个磁贴布局Bug，不过对于快速通道（Fast Ring）用户来说，可能并不会介意。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/ab0c7d4d510fd9f9ab6e43892c2dd42a2a34a4ce.jpg)
对于推送时间，Gabe Aul则表示今天时间已太晚，将不会选择在今天发布。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/1a5bc30e4bfbfbed8a7d209f71f0f736aec31f1a.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/cd45ac12495409231210759e9b58d109b1de49ce.jpg)
根据Gabe Aul的意思，想来新版本推送时间也不会太晚了。大家准备好升级吧。
北京时间2015年5月15日凌晨，Win10Mobile预览版Build 10080更新开始推送，开启Insider Fast模式的用户可以收到此更新。
本版已经新增支持机型：Lumia 930, Icon, 640, 640 XL、Lumia 540、HTC One M8、Xiaomi Mi4。
本版仍然存在诸多bug，所以不建议在主设备上运行。
你现在可以使用新版的应用商店Beta来下载通用版的Office应用软件，Xbox，音乐，视频。
一旦你成功安装build 10080，你就打开应用商店安装和测试Office应用程序：Word，Excel，PowerPoint和OneNote。
Spartan浏览器在这个版本里面还没有被更名为Edge。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/ec5b49dca3cc7cd9295427393001213fba0e91ce.jpg)
通用应用发威！Windows 10 Mobile预览版Build 10080更新内容一览
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/d01b11c7a7efce1b3355cd2aa651f3deb68f65cd.jpg)
***
Build 10080 更新在新增功能方面相对于以前的Build可谓史上变化幅度最大的 Build 版本。这次更新带来了专为手机应用设计的全新《应用商店(Beta)》、万众期待的通用版 Office 套件应用以及新版《Xbox》应用。
下面是微软官方公布的 Windows 10 手机预览版 Build 10080 更新日志：
1.专为手机推出的《应用商店(Beta)》：本次 Build 更新带来了全新面貌的 Windows 应用商店。你将会看到它被称为“应用商店(Beta)”。《应用商店(Beta)》采用了新型外观设计，如果你使用过 PC 版《应用商店(Beta)》，就会觉得它们非常相似，因为手机版《应用商店(Beta)》使用全新通用 Windows 平台代码编写而成。
由于是测试版，《应用商店(Beta)》中仍存在一些已知问题。包括商店中的“应用”与“市场”板块都存在诸多限制。大家可以浏览、搜索并下载应用。也可以通过国际信用卡、礼品卡或 PayPal 支付的方式购买付费应用/游戏。不过运营商支付功能仍未开启。
在 Build 大会上，我们宣布所有 Windows 10 设备（不只是手机)都将支持运营商支付功能。这意味着 Windows 10 消费者可以通过越来越多的运营商渠道来购买《应用商店(Beta)》中的所有内容。我们还在《应用商店(Beta)》中添加了音乐、电影、电视剧，以供全系 Windows 10 设备访问/购买。
“影视”板块现已开通，“音乐”板块暂不可用，但将很快开通。与 PC 端相同，当前的《应用商店(Beta)》已在 Build 10080 中正式启用。
2.通用版 Office 应用：现在 Build 10080 中已经带来了全新测试版《应用商店(Beta)》，大家可以从中下载《Word》《Excel》《PowerPoint》与《OneNote》预览版应用。大家可以访问我们的 Office 官方博客来浏览更多有关通用版 Office 应用的信息。我们知道大家等了很长时间，因此这次终于能为大家带来全新 Office 应用，我们也感到非常兴奋。
3.《Xbox》应用：Windows 10 版《Xbox》应用也在当前的《应用商店(Beta)》（v4.4.230）中首度现身。通过手机版《Xbox》应用，你可以访问你的活动源、成就、好友列表、活动提醒、消息，并观看游戏视频，还可连接你的 Xbox One 主机。大家可前往 Xbox Wire 新闻网站浏览更多信息。
4.预览版《音乐》应用：访问你的音乐收藏并播放你的所有音乐（包括添加至 OneDrive 中的音乐）。“正在播放”页面带来了全新体验，界面精致美观，支持轻松滑动手势切歌。
我们还会在以后的应用更新中为大家带来更多改进提升，包括在动态磁贴页面显示正在播放曲目、将音乐收藏固定至开始屏幕、探索完整目录、通过 Xbox Music Pass 订阅服务收听收音机、支持“儿童园地”、在《应用商店(Beta)》中购买付费音乐等。大家可在《应用商店(Beta)》中搜索“Music Preview”下载全新预览版《音乐》应用。
5.预览版《视频》应用：在你的设备中浏览并播放视频文件（包括 MKV 格式）。试试新添加的收藏筛选整理功能吧，你还可以在你的收藏中添加一个新的视频文件夹。
你还可以浏览/播放你在《应用商店(Beta)》中购买的电影/电视剧以及在 Xbox 《视频》中租借的影视内容。你可以在手机中接着观看之前在 PC 或 Xbox 中没有看完的付费视频。
在以后的应用更新中，我们将添加如下功能：下载电影/电视剧供离线播放、用于管理离线下载内容的全新设备管理模式、优化搜索结果、显示影评及演员信息等。大家可在《应用商店(Beta)》中搜索“Video Preview”下载全新预览版《视频》应用。
6.全新《相机》应用：我们希望大家为全新 Windows 10 《相机》应用积极提供反馈意见！大家可通过“设置”>“设备”>“Camera”来将《相机》应用设为默认相机应用（获将之固定到开始屏幕），并告诉我们你的想法。
需要注意的是，中端和高端 Lumia 设备（1520、1020、930、830、640 与 640XL）中的一些功能新款《相机》应用还暂不支持。如果想获得完整功能，这些手机用户还需下载使用《Lumia 专业拍摄》应用。在接下来的几周时间里，我们将为大家推出拥有完整功能的《相机》应用，并带来更多激动人心的特性。
7.一系列bug修复：点击e-mail通知消息直接进入邮件内容而不是日历，打入的电话也会正常播放铃声。
Windows 10 Mobile预览版Build 10080已知问题一览 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/92ef69f51bd5ad6e2837630a88cb39dbb4fd3c7d.jpg)
***
Windows 10 Mobile预览版 Build 10080 更新添加了大量新内容，同时也修复了一些上个版本中遗留的问题与 Bug ，但官方随即也列出了 Build 10080 中出现的新问题。
微软 Windows Insider 负责人 Gabriel Aul 今天发推公布了这次更新修复的问题：
引用: 现在点击邮件提醒将直接进入目标邮件而非《日历》中。来电铃音现在应该很响亮了。
据 Aul 表示，如果用户是由上个 Build 版本升级至 Build 10080 的话，将会在新版本中遇到一些迁移式问题：
•在升级完成后，你可能将会在应用列表中看到两个“搜索”与“电话”磁贴
•在升级完成后，一些应用可能会出现“Pending(等待)”标识且无响应。重启手机将解决这类问题
所有安装在 SD 卡中的应用数据与设置将不会随更新迁移，因此用户在升级后将无法继续使用或安装这些应用，只能卸载重装
在升级完成后，原《邮件》应用仍将继续在“All Apps(所有应用)”列表中出现，并带有“错误”标识且无法移除。如果该应用在升级前曾被固定在开始屏幕中，那么在更新后仍会继续存在，不过只需解除固定即可将之移除
此外 Aul 也列出了 Build 10080 中出现的其他问题：
•当从 WP8.1 升至 Windows 10 Mobile预览版 Build 10080 后，即便你在更新之前已打开了数据开关，它仍会在更新期间自动关闭。不过你可以在“设置”—“网络和无线”—“手机网络和 SIM 卡”重新打开数据开关
•非常重要：你可能无法再接收彩信了！通常情况下，当有人给你发送一条彩信而你手机数据开关又恰好关闭时，你将会在《消息》中收到“获取消息”的链接，在你手机联网后便可点击链接下载彩信内容。而新系统中存在一个 Bug ，使得系统无法接收彩信链接，因而彩信便完全丢失了。目前为保证彩信功能正常，只能一直保持手机数据连接畅通
•如果你所在地区已开通了 Cortana 服务（美国、中国、英国、法国、意大利、德国、西班牙），且你之前已更改了默认输入语言，请在更新之前确保已将系统区域、语言以及语音设置恢复到默认状态。否则将触发导致 “Cortana/搜索”频繁崩溃的 Bug
•在升级完成后，将一款应用卸载后，该应用可能不会从“所有应用”列表中被移除，如果你遇到了这种现象，通常重启手机即可解决该问题
在预览版《视频》（即《Video Preview》）应用中播放电影与电视剧时可能会出现 0x8004c029 错误
•在升级完成后，《Twitter》应用可能会在启动时崩溃，卸载重装应该会解决该问题
在《应用商店(Beta)》中安装的应用将不支持自动更新，你需要手动检查更新
•在由 Build 10052 更新至 Build 10080 后，《会员中心》应用仍无法启动。如果你是从 WP8.1 直升 Build 10080 ，则《会员中心》应用可以正常启动
Windows 10手机版Build 10080截图大赏&安装体验[多图] 
我们终于在一部 Lumia 925 上成功安装了 Windows 10 Mobile Build 10080 预览，带来了许多变化。我们为你准备了一些截图，详细了解 Build 10080 的一些重要变化，以及为我们带来了哪些新内容。
***
安装体验:
在良好的网络条件下更新下载需要大约25 - 30分钟，大小在500 - 800 MB。安装和数据迁移则需要20 - 25分钟。我的设备下载和安装相当顺利。你可能需要前往 Windows Insider应用重新选择加入内部参与者 Fast Ring，以后你可能需要重置设备以修复错误。
Windows 10 Mobile Build 10080 截图欣赏：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/553a51d2d539b6004da00f57e050352ac45cb7dd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/b6f7148ca977391297278581f1198618347ae2c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/6fdade399b504fc27431b0e5ecdde71192ef6ddd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/d41a971e3a292df553adacf5b5315c6036a873dd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/9da0314f9258d109728da952d858ccbf6e814ddd.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/b6d00c610c3387448dc42f9c580fd9f9d52aa0c6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f47beb5594eef01f8be21825e9fe9925be317d55.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/86a877395343fbf2cd2da6c3b97eca8067388fc6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/dea568b20f2442a7dd67fd45d843ad4bd31302dd.jpg)
接上面：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/92ef69f51bd5ad6e2cea670a88cb39dbb7fd3c30.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/4e007cd4ad6eddc4a3f4b71b30dbb6fd53663330.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/cb20d41d8701a18bb78212af972f07082a38fede.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/5b21ca6fddc451da72e50f0bbffd5266d1163230.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f20f24176d224f4a75f073f300f790529a22d1de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/2ef27a940a7b020846903c016bd9f2d3552cc8ee.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/94f352fbe6cd7b899e6c3a63062442a7db330ec6.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/553a51d2d539b6004da70f57e050352ac45cb7de.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/768ebdb54aed2e73a7e986cc8e01a18b85d6fac7.jpg)
接上面：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/d729c645ad345982388ae57205f431adc9ef84c7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/c5c182dce71190efd0fb923fc71b9d16fffa60c7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/cd45ac12495409236069639e9b58d109b1de49c7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/68cc7831e924b899915479d867061d95087bf6df.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/11c9419659ee3d6d05ae872b4a166d224d4adedf.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/dea568b20f2442a7dd0dfd45d843ad4bd31302c7.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f3ed8cc5b74543a99818fa2c17178a82bb0114c7.jpg)
Windows 10 Mobile Build 10080印象、Bug、更新问题和解决方案 
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/5d616d7a02087bf436a15a09fbd3572c13dfcff2.jpg)
现在我要分享 Build 10080 安装之后的初步印象，一些常见的 bug，更新存在的问题和解决方案。
1)相比 Build 10051，Build 10080 的 bug 更多一些， 但令人惊讶的是反而更稳定，运行更流畅。我起初遭遇了2 - 3次卡机，软启动之后一直很稳定。
2)在我看来，相对 Build 10051，Build 10080 改进了电池续航能力，耗电慢了。
3)上面截图中的 bug 可能让你有些看法，但我觉得你还是会喜欢 Build 10080。
4)屏幕概览等设置可以启动了，似乎功能上还有了增强(在之前的 Build 中不工作 )。
5)在上两个 Build 中的“无法截图”错误消息和语音下载问题 Build 10080 中仍然存在。
6)新音乐预览应用与 OneDrive 集成后感觉不错，我可以通过应用上传歌曲，并可以播放。
7)商店测试版运行良好，但仍需改进。
8)Office 预览应用是重头戏，目前至少可以说令人印象深刻。
9)《Get stated》应用现在可以运行了。
10)你可能也注意到了开始屏幕上的磁帖看起来与 Build 10051 有些不同。个性化选项如透明度滑块、颜色等自定义程度提升。
总的来说，一旦成功安装 Build 10080 之后，感觉上运行更稳定。许多早期 Build 中不工作的特性和设置现在都可以运行了。
***
Build 10080 Bug、更新问题 & 解决方案：
1)设备安装 Build 10080 后经常死机，软重启应该可以解决。
2)安装 Build 10080 后开始屏幕上没有显示磁贴，只显示在加载。首先尝试重新启动，如果不起作用尝试软重置，硬重置则是最后的选择。如果不能进入设置，通过手机按键尝试硬重置。
3)设备无限重启。再次使用手机按键硬重置。这是我们的重新设置教程。
4)视频和游戏应用在应用程序列表中显示 (@c:/data)，就像以上面截图所示的。
5)如果你不喜欢开始屏幕上的大号磁贴(在一些 Lumia 930 上)，可以前往设置- >个性化- >开始- >显示更多瓷砖- >设置为开启。
6)透明度不能正常应用。试着改变或删除背景，并再设置回来。如果不工作，尝试硬重置。
7)设置透明度开启，使“更多磁贴”选项关闭。尝试硬重置，它仍然无法正常运作，请等待下一个版本吧。
你也可以前往微软论坛，找寻更多 Build 10080 bug 和解决方法的帖子。
***
Win10Mobile预览版10080《Xbox》应用解析
Build 10080更新，带来了一系列全新通用版应用，其中就包括通用版《Xbox》应用，该应用将在正式版退出后正式取代《Smartglass》应用。
全新Win10手机版《Xbox》与桌面版《Xbox》的外观与功能性非常相似，相当于后者的迷你版本。
Build 10080更新并未引入Xbox One商店，它似乎是访问玩家自己游戏录像的通道。微软提醒大家手机版《Xbox》应用还只是非常早期的版本，这无异于暗示大家对应用中的Bug多加包涵。《Xbox》中的OneGuide功能就闹了个大笑话，大家可以前往《应用商店（Beta）》中搜索“Xbox”下载并自行尝试。
下面我们将通过一系列截图帮助大家对全新Win10手机版《Xbox》应用有个直观了解：
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f08aad8165380cd710f0ae0da844ad345b82815d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/e772ae167f3e67091cee491f32c79f3dfadc555d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f47beb5594eef01f97fa1425e9fe9925be317d5d.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/89e3183f6709c93da61c0217963df8dcd300545d.jpg)
真实用！Win10Mobile预览版10080新增快捷切换
在世界某些地区，人们经常会使用多种语言进行交流，手机用户也同样如此。因此许多手机用户经常需要在多个语言键盘间相互切换来选择合适的输入语言，而微软显然意识到了这点。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/edbfb61273f082025f8a9fdf42fbfbedaa641b2e.jpg)
在Win10 Mobile预览版10080中，微软为新系统引入了一种切换键盘语言的全新快捷方式：横向滑动空格键。已经安装了Win10Mobile预览版10080更新的朋友，如果你的手机也搭载了多个语种键盘，现在就可以尝试一下。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/4cc7e045ebf81a4c337be229de2a6059272da6fe.jpg)
Win10手机预览版10080：Edge/IE11浏览器HTML5跑分大涨
Win10Mobile预览版10080（第四次更新）已于今天推送，相信不少Windows Phone用户已经安装了这次更新。最新的Win10Mobile预览版10080更新已悄然大幅提升了两款内置web浏览器的HTML5性能。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/913cc087c9177f3eb697f5ed79cf3bc79d3d56a0.jpg)
***
包括Edge浏览器与IE浏览器的HTML5跑分成绩都有了显著提高。如上图所示，IE11浏览器的HTML5得分（390分）甚至比Edge浏览器的389分还高出一分。
在Windows10Mobile预览版首次更新推送后，IE11浏览器的HTML5跑分成绩为360，现在又飙升至390分，可谓进步显著。我们也希望微软继续保持对Win10手机版web浏览器的优化，在下次更新时取得更好成绩。
Win10手机预览版10080鼠标光标另有“深意”
***
众所周知，WP8.1 GDR2更新为WP设备带来了蓝牙键盘与蓝牙鼠标连接功能，当时用户无法通过蓝牙鼠标控制手机，但二者已能建立连接。而在微软宣布针对Win10手机的Continuum平板模式后，设置这一功能的目的就更加明朗了。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/3deab51a0ef41bd54531e31458da81cb3bdb3de1.jpg)
***
在Win10Mobile预览版10080更新完成后，许多用户都发现手机左上角出现了鼠标光标。有用户就此咨询了Insider项目负责人Gabe Aul，后者回复称屏幕中的鼠标光标暂时不可用，但也有支持该功能的必要，它之所以会在手机中出现，是因为微软在Build 10080中引入部分Continuum平板功能代码的缘故。
虽然为Win10手机配备蓝牙键盘与鼠标会影响其移动属性，但如果用户希望通过Continuum平板模式获得完整PC体验，则需要使用鼠标键盘加以辅助。因此微软也一直在制造越来越多的蓝牙键盘与蓝牙鼠标。此外，Win10手机系统中开始引入Continuum代码对于我们来说也是个好消息！
***
视频演示：Windows 10 Mobile Build 10080鼠标操作实况 
Windows 10 Mobile Build 10080，在这一版本里可以将鼠标连接到手机上，像任何其他外设一样来使用。在下面的视频中可以看到这个功能的工作情况，现在这还是一个新颖的特性，微软没有对此广泛宣传。
Win10手机预览版10080：Wordflow键盘支持新语言
Win10Mobile预览版10080主要致力于UI提升、Bug修复以及新应用添加等。除了大量新功能外，Windows10手机预览版的各种本地化属性也在增强。据用户反映，Build 10080更新为Wordflow键盘增加了新语言支持。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/8861b642ad4bd1138ddbc2d253afa40f4afb0535.jpg)
***
Win10Mobile预览版10080中的Wordflow键盘现已支持丹麦语、波斯语以及克罗地亚语。由于上述三种新增语言均来自当地用户反馈，因此Win10Mobile预览版10080更新可能还为Wordflow键盘添加了一些其他语言。
Win10Mobile预览版10080：那些你错过的功能
Win10Mobile预览版10080更新中包含了大量新添加内容，但仍有一些细微变动不曾被发现。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/8f0879168a82b9015849b4d37a8da9773b12ef5b.jpg)
下面我们一起看看大家可能错过了那些新内容：
即将到来的Skype整合
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f3e8e000a18b87d603a6dcff0e0828381d30fd5b.jpg)
这个新特性很容易被用户忽视，因为它只会在初始设置中出现。我们还不确定它将以哪种形式出现，仅从权限申请来看，该特性很容易让人联想起iMessage功能。
《Contact Support》
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/42fc1cf50ad162d9c60a15fc18dfa9ec8813cd5b.jpg)
与Windows10桌面版类似，现在系统内置了一款新的《Contact Support》应用，目前该应用还无法使用，但至少我们知道它也将登陆Win10Mobile系统了。
诺基亚设置现身应用列表
更新Win10Mobile预览版10080后，手机中所有的诺基亚设置都被移出《设置》面板并下放至应用列表，与WP8.1中的游戏境遇相似。这既有可能是一项未公布的Bug，也有可能是微软准备在未来更新中处理OEM功能的先兆。是全部整合到《设置》还是下放至应用列表，我们将拭目以待。
地图
现在《地图》应用添加了暗色主题与更大胆更浓郁的颜色。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/11fbbef8d72a60597af496fa2134349b013bba5b.jpg)
在功能方面，《地图》现在已能监测出路上可能影响用户行程的偶发事件，如施工或交通事故等。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/d17bc7ed08fa513d66091b3e346d55fbb0fbd9a0.jpg)
与之前版本的《地图》相比，用户可在当前版本中获得更多关于出发时间与到达时间的控制选项。就实际效果来说，新版《地图》在功能性与用户体验方面要优于WP8版本。
人脉
现在《人脉》应用比上个版本的功能更加完善，Feeds显示更加一致，群组界面UI变动，多个群组以一个列表形式显示。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/6fdade399b504fc241bbc7e5ecdde71192ef6d5b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/bd0ec850f3deb48f2d8dd63ef91f3a292ff5785b.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/bb06d5109313b07ebf1e27e805d7912395dd8ca0.jpg)
Win10Mobile预览版仍非常粗糙，其打磨程度仍不及当前的Win10桌面版本，不过它的逐步演变也让我们对微软的设计开发走向有了更深入的了解。
北京时间2015年5月18日，Win10手机预览版10080商店下载问题已修复
微软在Win10Mobile预览版10080中新增了几项大功能，最重要的当属Win10 Mobile商店Beta，因为新版Office应用也要从这里进行下载，不过此前商店下载遇到了拥堵问题，微软已着手解决。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/94f352fbe6cd7b896ca84c63062442a7db330e7b.jpg)
***
在Windows10手机预览版10080推送初始，用户在新商店下载应用经常遇到“Working…”等待显示问题，却不能下载应用。Windows Insider负责人Gabe Aul表示，微软已经修复商店下载问题，如果大家还有遇到，可以尝试重启手机再试一下。
笔者在装了Win10手机预览版的Lumia830上测试，结果表明应用已经可以正常下载，遇到该问题的网友不妨现在再去试一下。
Win10Mobile预览版10080《音乐》正修正此前错误
2014年的Build大会，微软很兴奋的推出了Windows Phone 8.1系统，承诺带来诸如Cortana、透明动态磁贴以及滑动输入等等新功能，另外还有重写版的Xbox Music应用，独立于系统之外。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/9596e234e5dde71106583216aeefce1b9f1661b9.jpg)
然后，我们都知道了。WP8.1版Xbox Music应用性能极弱，备受批评。尽管可以在商店内持续更新，但是每次更新都是修复Bug，直到现在也没有达到令人很满意的程度。
值得庆幸的是，微软已经意识到问题所在，下面一起看看Win10 Mobile预览版上的Music应用。
视觉设计
首先注意到的是Music预览应用非常不同，甚至更好。微软在Windows10系统中正推进“Metro 2.0”设计，播放/暂停控制、上一曲/下一曲播放、重复播放等等，功能轻量化，风格更出彩。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/f7b124a88226cffc13ecce52b0014a90f403ea05.jpg)
UX改变
有几个明显改善的地方，首先正在播放再次允许用户通过水平滑动操作跳至下一首，希望可以加入一些视觉效果，让用户了解该手势。事实上，这是原始ZUNE客户端的功能回归，这是许多人的最爱。
同等重要的是播放控件，现在已经充满屏幕宽度。UX简洁高效，最后在锁屏界面上音乐播放也是相同效果。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/c0fe7ed9bc3eb135884dc65baf1ea8d3ff1f44b9.jpg)
导航是应用的另一部分，浏览收藏，查看最近播放，或者管理自定义电台，当然都需要点击左上角的汉堡菜单。笔者并不认为汉堡菜单都是错误的，但是将频繁使用的功能放到菜单中就会令人感到不便。汉堡菜单更适合在PC大屏幕上使用鼠标操作。
还有改进的余地，但是开始是好的
一些地方还需要改善，比如锁屏界面的音乐播放控件没有和锁屏融合，当然作为测试应用，Bug难免存在。希望Win10版Xbox Music应用进化的越来越好。
Win10Mobile 10080：Cortana微软小娜歇菜，请这样修复
2015年5月15日，微软向Windows Insider用户推送了Win10Mobile Build 10080，还总结了Win10Mobile预览版10080已知Bug，其中有Cortana微软小娜遭遇一部分问题。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/792fd1fc5266d016e1b1edc89e2bd40737fa359f.jpg)
“如果你的Cortana是开启的（美国、中国、英国、法国、意大利、德国和西班牙），并且你曾经更改过默认出厂设置语言和地区——那么在开始更新前，请确保地区、语言和语音设置保持默认一致。这样做是为了避免Cortana出现搜索崩溃Bug。”
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/eb90644e78f0f736ad553fe10355b319e9c4139f.jpg)
▲左边是有问题的Cortana，右边是临时修复的Cortana
如果没有按照上面的做，在升级到Windows10Mobile预览版10080后，你可能发现Cortana的动态磁贴不能正常显示，并且启动失败和崩溃。解决这个问题需要先取消Cortana磁贴显示，然后到程序列表中重新Pin一下“Search”应用，其工作原理与Cortana一样。
小米4刷上Win10Mobile预览版Build10080
在2015年3月份的深圳WinHEC大会上，微软与小米合作推出小米手机4版Win10 Mobile刷机包，在2015年6月1日宣布内测Win10 Mobile系统ROM，2015年6月2日MIUI论坛中已经有网友晒出刷了Win10Mobile预览版的小米4手机照片。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/3b006dd062d9f2d378b8590fa0ec8a136127cc9e.jpg)
小米4的Win10 Mobile就是2015年5月15日微软向广大Lumia用户推送的Windows10 Mobile预览版10080。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/4a2505d8f2d3572c214be13c8313632760d0c39e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/222d95d2572c11df9878c2c36a2762d0f503c29e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/b227302d11dfa9ecb8872bf76bd0f703938fc19e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/17d876dea9ec8a1350b32a00fe03918fa2ecc09e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/512bceed8a1363275644bfd3988fa0ec0afac79e.jpg)
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/e918ed12632762d0c297d95fa9ec08fa533dc69e.jpg)
视频：Win10Mobile预览版10080上手尝鲜
最新的Win10Mobile预览版10080更新已经推送，也已改为Windows10 Mobile Insider PreView。外媒Windows Central带来Lumia830升级Win10手机预览版的视频体验。
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/5020614879/0b0f9cecab64034f84c0bde6a6c379310b551d32.jpg)
在Win10Mobile预览版10080中已出现Windows应用商店Beta，允许你安装通用Office应用、Xbox、音乐和视频。Window商店采用新的外观设计，你可以浏览和搜索，也可以下载应用。另外还有电影和TV节目，音乐栏目会稍后带来。
而微软Edge浏览器还是之前的Project Spartan斯巴达，中国版Edge浏览器已经全面汉化。
Build 10052、Build 10080已更新完毕[滑稽]下期预告：Build 10136、Build 10149，欢迎催更[滑稽][滑稽][滑稽]
