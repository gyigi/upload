修复版本的longhorn4093，使用的是4093PE。winlogon破解适用于所有重组前longhorn版本（注意不同build的破解版本winlogon只能对应这个特定的build），之所以要winlogon破解，是因为4xxx的某个build起winlogon会检测激活状态，即使用antiwpa激活了也不行[喷]
4093来自longhorn。ms，下面是原网站说明文档：
__ _ _ __ __ _____ __
 / / | | | | | \/ | / | \ \  / / | | ___ _ __ __ _ | |__ ___ _ __ _ __ | \ / || (___ \ \ 
 / / | | / _ \ | '_ \ / _ || '_ \ / _ \ | '__|| '_ \ | |\/| | \___ \ \ \ 
 / / | |____| (_) || | | || (_| || | | || (_) || | | | | | _ | | | | ____) | \ \ 
 /_/ |______|\___/ |_| |_| \__, ||_| |_| \___/ |_| |_| |_|(_)|_| |_||_____/ \_\
 __/ | 
 |___/
***
Build 4093, originally leaked at August 28, 2006 leaked as a heavily edited ISO. 
As the original 4093 ISO wasn't bootable the C0d3rz team made a bootable ISO using 4033 winpe. 
They edited startnet.cmd to start 4093's setup from the usa_4093_x86fre.pro_longhorn directory in the ISO.
***
Until today (1st May 2014) the C0d3rz ISO was to be used if one would like to install 4093.
Not anymore, as Luk釟 in collaboration with Melcher were able to put the original 4093 WinPE to work.
***
We, from longhorn.MS, proudly present to you, the proper release of Longhorn Build 4093 with its own PE!
***
Install notes:
-Unzip
-Mount or burn image
-Install with this key: TCP8W-T8PQJ-WWRRH-QH76C-99FBW
***
We would like to thank Hounsell for hosting our website and letting us host the download of the fixed copy
***
地址：
链接：![](http://pan.baidu.com/s/1kVns3Q3 密码：kxl7
***
某三剑客镇楼[滑稽]
![](https://wvbarchive.s3-ap-northeast-1.amazonaws.com/4868929807/f0a59f188618367a7b38f7e227738bd4b21ce556.jpg)
@cghvbnv22 @longhorn4093
