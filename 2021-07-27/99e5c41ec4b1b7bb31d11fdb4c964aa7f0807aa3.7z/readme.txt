本程序使用Visual C++ 6.0编译.
编译时请将编译选项调整为UNICODE编译.

使用GPL v2.0协议发布.
Ghdgtdgu, 2021.07.27